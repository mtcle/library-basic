
/**
 * 中文名字：天天爱消除
 * English name：DayDayLoveDestory
 * 版本：1.0
 * @Mtcle  
 * 2013.12.13
 *   
 *   
 *程序实现：
 *声明一个7X7的二维数组
 *设置为静态类型
 *通过getFuhao方法通过随机数产生一个初始符号表
 *通过printFuhao方法打印出来
 *通过hangX方法和lieX方法对初始二维数组表进行消除赋值
 *通过panDuanHang和panDuanLie方法判断通过消除后的是否还有可以消除的
 *循环调用方法，直到没有消除的为止。 
 * 
 * @author mtcle
 * @since jdk1.7
 * */
public class DayDayLoveDestory {
  final static char[] ku = {'o', '*', '+', 'x', '-', '$'};//声明的符号库，便于以后扩展
  static int sumhang = 0;//统计行消除次数
  static int sumlie = 0;//统计列消除次数
  static int sum = 0;//总消除次数
  static char[][] fuhao = new char[7][7];//初始二维数组，有getFuaho（）进行赋值

  public static void main(String[] args) {// 主方法
    getFuhao();// 获得符号表单
    System.out.println("初始符号盘：");
    PrintFuHao(fuhao);// 打印初始表单
    do {
      hangX();//调用行消除方法消除
      System.out.println("行消除次数:" + sumhang);//打印消除后的以及消除次数
      lieX();//调用列消除方法消除
      System.out.println("列消除次数:" + sumlie);
    } while (panDuanHang() == 1 || panDuanLie() == 1);// 用do-while循环判断是否还有继续能消。
    
    
    System.out.println("最后的不能消除状态：");
    PrintFuHao(fuhao);//打印最后状态
    System.out.println("\n总共消除次数: " + sum);
  }

  public static void PrintFuHao(char[][] a) {// 打印符号表
    for (int i = 0; i < 7; i++) {
      for (int j = 0; j < 7; j++) {
        System.out.print(a[i][j] + " ");
      }
      System.out.println();
    }
    System.out.println("\n");
  }



  public static void getFuhao() {// 获得符号赋值给二维数组
    for (int i = 0; i < 7; i++) {
      for (int j = 0; j < 7; j++) {
        int temp = (int) (Math.random() * 6);//调用系统math的随机数方法随机为二维数组赋值
        fuhao[i][j] = ku[temp];
      }
    }
  }


  
  /*
   * 
   * 
   * 判断列是否还能消除
   */
  public static int panDuanLie() {// 判断列重复的方法
    int aaa = 0;
    for (int i = 0; i < 7; i++) {
      for (int j = 0; j < 5; j++) {
        if (fuhao[i][j] == fuhao[i][j + 1] && fuhao[i][j + 1] == fuhao[i][j + 2]) { // 判断行里是否有连续三个相同的
          aaa = 1;
          break;
        }
      }
    }
    return aaa;
  }



  /*
   * 
   * 判断行是否有重复的
   */
  public static int panDuanHang() {// 判断行重复的方法
    int aaa = 0;
    for (int j = 0; j < 7; j++) {
      for (int i = 0; i < 5; i++) {
        if (fuhao[i][j] == fuhao[i + 1][j] && fuhao[i + 1][j] == fuhao[i + 2][j])// 判断列里是否有连续三个相同的
        {
          aaa = 1;
          break;
        }
      }
    }
    return aaa;
  }



  /*
   * 定义消除行的方法
   */
  public static void hangX() {// 定义消除行方法
    for (int i = 0; i < 7; i++) {
      for (int j = 0; j < 5; j++) {
        if (fuhao[i][j] == fuhao[i][j + 1] && fuhao[i][j + 1] == fuhao[i][j + 2]) {
          fuhao[i][j] = ku[(int) (Math.random() * 6)];
          fuhao[i][j + 1] = ku[(int) (Math.random() * 6)];
          fuhao[i][j + 2] = ku[(int) (Math.random() * 6)];
          sum++;
          sumhang++;
          System.out.println(sumhang + " 次行消除后：");
          PrintFuHao(fuhao);
        }
      }
    }

  }

  /*
   * 
   * 
   * 
   * 
   * 
   * 定义消除列的方法
   */
  public static char[][] lieX() {// 定义消除列方法
    // int a = 0;
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 7; j++) {
        if ((fuhao[i][j] == fuhao[i + 1][j] && fuhao[i + 1][j] == fuhao[i + 2][j])) {
          fuhao[i][j] = ku[(int) (Math.random() * 6)];
          fuhao[i + 1][j] = ku[(int) (Math.random() * 6)];
          fuhao[i + 2][j] = ku[(int) (Math.random() * 6)];
          sumlie++;
          sum++;
          System.out.println(sumlie + " 次列消除后：");
          PrintFuHao(fuhao);
        }
      }
    }
    return fuhao;
  }

}
