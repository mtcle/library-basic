package work1;

public class Messageprint {
//测试的文档test
	/**ghghghgh
	 * @mtcle the first javawork
	 */
	public static void main(String[] args) {
		System.out.println("Welcome\" to Java");//这里是注释
		System.out.println("Welcome to computer Science");//也是注释
		System.out.println("Programming is fun");//还是注释
		
	}

}
