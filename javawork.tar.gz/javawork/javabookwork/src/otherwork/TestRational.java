package otherwork;

import java.util.Scanner;

public class TestRational {

  public static void main(String[] args) {
    System.out.println("请输入要计算的分式：");
    @SuppressWarnings("resource")
    Scanner input = new Scanner(System.in);
    String str = input.next();
    Str bb = new Str();
    Rational sum = new Rational();
    int n1 = bb.getNumber(str)[0];
    int d1 = bb.getNumber(str)[1];
    int n2 = bb.getNumber(str)[2];
    int d2 = bb.getNumber(str)[3];
    @SuppressWarnings("unused")
    Str aa = new Str();
    Rational a1 = new Rational(n1, d1);
    Rational a2 = new Rational(n2, d2);
    switch (bb.getFuhao(str, bb.getFuhaoWeiZhi(str) + 3)) {
      case '+':
        sum = a1.add(a2);
        break;
      case '-':
        sum = a1.jian(a2);
        break;
      case '*':
        sum = a1.chengFa(a2);
        break;
      case '%':
        sum = a1.chuFa(a2);
        break;
    }
    System.out.println(str + " = " + sum.toString());
  }
}



/**
 * 声明了一个类
 * 只要负责处理字符串
 * 通过处理字符串获得运算符以及参与运算的数值
 * @author mtcle
 * @since jdk1.7
 * */
class Str {
  public int getFuhaoWeiZhi(String str) {// 获得符号位下标的位置

    return str.indexOf('+') + str.indexOf('-') + str.indexOf('*') + str.indexOf('%');// 找不到返回的是-1
  }

  public char getFuhao(String str, int i) {// 获得了运算符号
    return str.charAt(i); // 查找特定位置的char
  }

  public int[] getNumber(String str) {
    int[] num = new int[4];// 定义一个四个元素的整型数组分别存放这两个分数的分子分母
    String str1 = new String();
    String str2 = new String();
    String str3 = new String();
    String str4 = new String();
    str1 = str.substring(0, str.indexOf('/'));
    str2 = str.substring(str.indexOf('/') + 1, getFuhaoWeiZhi(str) + 3);
    str3 = str.substring(getFuhaoWeiZhi(str) + 4, str.indexOf('/', getFuhaoWeiZhi(str) + 3));
    str4 = str.substring(str.indexOf('/', getFuhaoWeiZhi(str) + 3) + 1);
    num[0] = Integer.valueOf(str1);
    num[1] = Integer.valueOf(str2);
    num[2] = Integer.valueOf(str3);
    num[3] = Integer.valueOf(str4);
    return num;
  }


}

