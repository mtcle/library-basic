package otherwork;

public class TestArrays {//测试类

  public static void main(String arg[]) {
    int i = 0;
    String[] a = new String[10];
    Array<String> test = new Array<String>(a);
    do {
      test.input("1111");
      test.input("2222");
      test.input("3333");
      test.input("4444");
      i++;
    } while (i < 50);
    // System.out.println(test.getTemp());// 当前容量位置
    System.out.println("入栈顺序：" + test.toString());
    test.output();
  }
}



class Array<T> {//定义一个泛型类
  private T[] a;
  private int x = 10;// 定义容量
  private int temp = 0;// 标识容量位置

  public Array(T[] a) {
    this.a = a.clone();
  }

  public T[] getA() {
    return a;
  }

  public void setA(T[] a) {
    this.a = a;
  }

  public int getX() {
    return x;
  }

  public int getTemp() {
    return temp;
  }

  public void setX(int x) {
    this.x = x;
  }

  public T[] input(T a) {// 输入数据

    if (this.decide()) {
      this.a[temp] = a;
      temp++;
    } else {
      this.setX(this.x + 10);
      this.copyToNew();
      this.a[temp] = a;
    }
    return this.a;
  }

  public void output() {// 取出数据
    System.out.print("出栈顺序：");
    if (decide()) {
      for (int i = temp - 1; i >= 0; i--) {
        System.out.print(a[i]);
      }
    }
  }


  public boolean decide() {
    if (temp < this.x)// 判断是否满，不满返回true
      return true;
    else {
//      System.out.println("堆栈满了！增加一次容量.....");
      return false;
    }
  }

  @SuppressWarnings("unchecked")
  public void copyToNew() {
    // System.out.println("copy");
    Object[] x = new Object[this.x];
    for (int i = 0; i < temp; i++) {
      x[i] = a[i];
    }
    a = (T[]) x;//强制类型转换一下，将扩容后赋值后的数组引用传递给a
  }



  public String toString() {
    StringBuilder str = new StringBuilder();
    for (int i = 0; i < this.temp; i++) {
      str.append(this.a[i]);
    }
    return str.toString();
  }

}
