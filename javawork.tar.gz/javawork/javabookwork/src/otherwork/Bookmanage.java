package otherwork;
import java.util.Scanner;
public class Bookmanage {
static int[]date;
static int[] bookstatus={2,2,2};
static String[] book;
static int[]bookoutsum;

  /**
   * @param args
   */
  public static void main(String[] args) {
    String[] book = new String[3];
    book[0]="简爱";
    book[1]="飘";
    book[2]="罗马假日";   
    int choice=0;
    do{
    System.out.println("欢迎使用图书管理系统");
    System.out.println("-----------------");
    System.out.println("1.新增图书");
    System.out.println("2.查看图书");
    System.out.println("3.删除图书");
    System.out.println("4.借出图书");
    System.out.println("5.归还图书");
    System.out.println("6.退出系统");
    System.out.println("-----------------");
    System.out.println("请选择：");
    Scanner input = new Scanner(System.in);    
    choice = input.nextInt();    
    switch (choice) {
      case 1:
        addNewBook();
        break;
      case 2:
        viewBook(book );
        break;
//      case 3:
//        delBook();
//        break;
      case 4:
//        System.out.println("11222");
        checkOut(book ,bookstatus,bookoutsum);
        break;
//      case 5:
//        checkIn();
//        break;
//      case 6:
//        closeSys();
//        break;
      default:
        System.out.print("请输入正确的数字！");    
    }
    
    }while (choice==6);
  
    }
  public static String[] addNewBook() {// 增加新图书方法
    int sumBook = 0;// book数量，满的话定义是10本
    String[] book = new String[10];
    book[0]="简爱";
    book[1]="飘";
    book[2]="罗马假日";
    if (sumBook < 10) {
      System.out.println("书架未满请输入书名：\n");
      Scanner input = new Scanner(System.in);
      String newOne = input.next();
      book[sumBook + 1] = newOne;
      sumBook = sumBook + 1;
    } else {
      System.out.print("书架已满！");
      
    }
    System.out.print("已经添加！");
    return book;
  }

  public static void viewBook(String[] book) {// 查看图书
    int i = 0;
    System.out.println("序号\t"+"书名\t"+"状态\t"+"借出日期\t"+"借出次数");
    for (i = 0; i < book.length; i++) {
      System.out.print(i+1+"\t"+book[i]+"\t");
      if (bookstatus[i]==1){System.out.print("在馆"+"\t");}
      else {System.out.print("借出"+"\t");}
      System.out.print(date+"\t");
      System.out.println(bookoutsum+"\t");
      
//      System.out.println("112222");
    }
  }

  public static void delBook(String[] book) {
    // 先写借出的方法
  }

  public static void checkOut(String[] book, int[] bookstatus, int[] bookoutsum) {// 传进来的参数应该有书的字符串数组，书借出状态，图书借出次数
    System.out.println("请输入你要借阅的书名：");
    @SuppressWarnings("resource")
    Scanner input = new Scanner(System.in);
//    int[]status= new int[book.length];
    String name = input.next();
    for (int i = 0; i < book.length; i++) {
      if (book[i].equals(name)) {
        if (bookstatus[i] == 1) 
          {System.out.println("该书已经被借出！");
//          System.out.println(book[i]);
          }
        else 
          {System.out.println("输入借出日期:");
          @SuppressWarnings("resource")
          Scanner temp = new Scanner(System.in);
          int booktime = temp.nextInt();
            if (booktime > 0 && booktime < 32){ 
            bookstatus[i] = 1;// 图书状态1代表借出，2代表在书架上
            bookoutsum[i] = bookoutsum[i] + 1;
                }// 图书数量减一
            else{
              System.out.print("请输入正确的借书日期1~31：");
              @SuppressWarnings("resource")
              Scanner date1=new Scanner(System.in);
              int dateout=date1.nextInt();
              date[i]=dateout;
                }
          }
        System.out.println("该书不存在！");
        }       
       else     
         System.out.println("212121212121");      
    }    
  }

 
  public static String[] delBook(String[] book, int[] bookstatus) {//刪除图书的方法
    Scanner temp = new Scanner(System.in);
    String temp1 = temp.next();
    String[] bookNew = new String[book.length];
    for (int i = 0; i < book.length; i++) {
      if (book[i].equals(temp1)) {
        if (bookstatus[i] == 1) {
          System.out.print("图书已经借出，无法删除");
        } else {
          book[i - 1] = book[i];
          for (int j = 0; j < book.length - 1; j++) {// 将删除末尾的字符串数组复制给新的字符串数组，因为数组声明过后无法改变长度了
            bookNew[j] = book[j];
          }
        }

      } else {
        System.out.print("该图书不存在！无法删除！");
      }
    }
    return bookNew;
  }
  
  
  public static void checkIn(String[]book){
    Scanner input=new Scanner(System.in);
    String temp=input.next();
    for(int i=0;i<book.length;i++){
       if (book[i].equals(temp)){
         if  (bookstatus[i]==1){
           System.out.print("输入归还日期1-31");
           Scanner checkInDate=new Scanner(System.in);
           int datein=checkInDate.nextInt();
           if (datein>=date[i] && datein<32){
             System.out.println("计算费用："+(datein-date[i]));
           }
           else System.out.println("请输入正确的日期！"); 
         }
         else System.out.println("未被借出");
       }
       else System.out.println("没有查到此书！");
    }
    
  }




}
