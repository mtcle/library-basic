/*闫新亚*/
/*实现的功能：可以产生了非负值的了。
/*缺少的功能：不符合要求的未输出后不够的无法补全，不能确保无重复。
/******************************************************/
//
package otherwork;
import java.util.*;
public class Studentmath {// 主方法
  public static void main(String[] args)
 {
    @SuppressWarnings("resource")
    Scanner input = new Scanner(System.in);
    System.out.println("Enter the number of question:");
    int sum1 = input.nextInt();
    System.out.println("以下是系统为您出的数学题：");
    for (int j = 0; j < sum1; j++) {
      getMath(sum1);    
      }   
    }
  public static void getMath(int number)// 获取一道题的方法
  {
    StringBuffer ss = new StringBuffer();
    int i, p, q, n, m = 0,sum = 0;
    char[] fuHao = {'+', '-', 'x'};
    do {
      for (p = 0; p < 3; p++) {
        i = (int) (Math.random() * 9 + 1);//生成随机的运算值
        n = (int) (Math.random() * 3);//生成随机的运算符的下标值
        {
          ss.append(i);//将随机数追加到ss后面
          ss.append(fuHao[n]);//紧跟着追加一个随机的运算符
          m = m + 1;//统计运算符的数量是否满足条件
        }
      }
      ss.append((int) (Math.random() * 9 + 1));
      ss.append("=");
      // System.out.println(ss);
    } while (m < 2);
    String str = ss.toString();// 将ss转换成String型
    char[] ssChar = str.toCharArray();// 将str转换成char[]
    StringBuffer fuhao = new StringBuffer(); // 判断符号位置
    for (i = 1; i < 7; i = i + 2) {
      fuhao.append(ssChar[i]);//将操作运算符存入ssChar[]中
    }
    String fuhaoString = fuhao.toString(); //将fuhao转变成字符串数组
    String[] suanFa =
        {"+++", "---", "xxx", "++-", "++x", "+--", "+xx", "+x-", "+-x", "+-+", "+x+", "--x", "-xx",
            "-++", "-+x", "-x+", "xx+", "xx-", "x--", "x++", "x+-", "x-+", "x-x", "x+x", "-x-",
            "-+-", "--+"};//定义操作运算符的字符串数组
    for (p = 0; p < 27; p++) {
      if (suanFa[p].indexOf(fuhaoString) != -1) //运用indexof（）寻找字符串在字符串数组中的位置，然后返回下标值。
      {
        q = p;
        switch (q) { //进行匹配相应的运算方式
          case 0:
            sum = (ssChar[0] - 48) + (ssChar[2] - 48) + (ssChar[4] - 48) + (ssChar[6] - 48);
            break;
          case 1:
            sum = (ssChar[0] - 48) - (ssChar[2] - 48) - (ssChar[4] - 48) - (ssChar[6] - 48);
            break;
          case 2:
            sum = (ssChar[0] - 48) * (ssChar[2] - 48) * (ssChar[4] - 48) * (ssChar[6] - 48);
            break;
          case 3:
            sum = (ssChar[0] - 48) + (ssChar[2] - 48) + (ssChar[4] - 48) - (ssChar[6] - 48);
            break;
          case 4:
            sum = (ssChar[0] - 48) + (ssChar[2] - 48) + (ssChar[4] - 48) * (ssChar[6] - 48);
            break;
          case 5:
            sum = (ssChar[0] - 48) + (ssChar[2] - 48) - (ssChar[4] - 48) - (ssChar[6] - 48);
            break;
          case 6:
            sum = (ssChar[0] - 48) + (ssChar[2] - 48) * (ssChar[4] - 48) * (ssChar[6] - 48);
            break;
          case 7:
            sum = (ssChar[0] - 48) + (ssChar[2] - 48) * (ssChar[4] - 48) - (ssChar[6] - 48);
            break;
          case 8:
            sum = (ssChar[0] - 48) + (ssChar[2] - 48) - (ssChar[4] - 48) * (ssChar[6] - 48);
            break;
          case 9:
            sum = (ssChar[0] - 48) + (ssChar[2] - 48) - (ssChar[4] - 48) + (ssChar[6] - 48);
            break;
          case 10:
            sum = (ssChar[0] - 48) + (ssChar[2] - 48) * (ssChar[4] - 48) + (ssChar[6] - 48);
            break;
          case 11:
            sum = (ssChar[0] - 48) - (ssChar[2] - 48) - (ssChar[4] - 48) * (ssChar[6] - 48);
            break;
          case 12:
            sum = (ssChar[0] - 48) - (ssChar[2] - 48) * (ssChar[4] - 48) * (ssChar[6] - 48);
            break;
          case 13:
            sum = (ssChar[0] - 48) - (ssChar[2] - 48) + (ssChar[4] - 48) + (ssChar[6] - 48);
            break;
          case 14:
            sum = (ssChar[0] - 48) + (ssChar[2] - 48) + (ssChar[4] - 48) * (ssChar[6] - 48);
            break;
          case 15:
            sum = (ssChar[0] - 48) - (ssChar[2] - 48) * (ssChar[4] - 48) + (ssChar[6] - 48);
            break;
          case 16:
            sum = (ssChar[0] - 48) * (ssChar[2] - 48) * (ssChar[4] - 48) + (ssChar[6] - 48);
            break;
          case 17:
            sum = (ssChar[0] - 48) + (ssChar[2] - 48) + (ssChar[4] - 48) - (ssChar[6] - 48);
            break;
          case 18:
            sum = (ssChar[0] - 48) * (ssChar[2] - 48) - (ssChar[4] - 48) - (ssChar[6] - 48);
            break;
          case 19:
            sum = (ssChar[0] - 48) * (ssChar[2] - 48) + (ssChar[4] - 48) + (ssChar[6] - 48);
            break;
          case 20:
            sum = (ssChar[0] - 48) * (ssChar[2] - 48) + (ssChar[4] - 48) - (ssChar[6] - 48);
            break;
          case 21:
            sum = (ssChar[0] - 48) * (ssChar[2] - 48) - (ssChar[4] - 48) + (ssChar[6] - 48);
            break;
          case 22:
            sum = (ssChar[0] - 48) * (ssChar[2] - 48) - (ssChar[4] - 48) * (ssChar[6] - 48);
            break;
          case 23:
            sum = (ssChar[0] - 48) * (ssChar[2] - 48) + (ssChar[4] - 48) * (ssChar[6] - 48);
            break;
          case 25:
            sum = (ssChar[0] - 48) - (ssChar[2] - 48) * (ssChar[4] - 48) - (ssChar[6] - 48);
            break;
          case 26:
            sum = (ssChar[0] - 48) - (ssChar[2] - 48) + (ssChar[4] - 48) - (ssChar[6] - 48);
            break;
          case 27:
            sum = (ssChar[0] - 48) - (ssChar[2] - 48) - (ssChar[4] - 48) + (ssChar[6] - 48);
            break;
        }
      }
    }
    if (sum >= 0)//如果结果不为负则打印输出
    System.out.println(ss);      
  }
}
