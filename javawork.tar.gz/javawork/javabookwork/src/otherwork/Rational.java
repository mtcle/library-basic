package otherwork;


@SuppressWarnings({"serial", "rawtypes"})
public class Rational extends Number implements Comparable {
  private long numerator = 0;
  private long denominator = 1;

  public Rational() {
    this.numerator = 0;
    this.denominator = 1;
  }

  /**
   * 约分
   */
  public Rational(long numerator, long denominator) {
    long gcd = gcd(numerator, denominator);// 调用公约数函数
    this.numerator = ((denominator > 0) ? 1 : -1) * numerator / gcd;// 防止符号被消了，都用绝对值，最后加上符号位！
    this.denominator = Math.abs(denominator / gcd);
  }

  /**
   * 对分式分子分母找出最大公约数
   */
  public static long gcd(long n, long d) {
    long n1 = Math.abs(n);
    long n2 = Math.abs(d);
    int gcd = 1;
    for (int k = 1; k <= n1 && k <= n2; k++) {
      if (n1 % k == 0 && n2 % k == 0) gcd = k;
    }
    return gcd;
  }

  public long getNumerator() {
    return numerator;
  }

  public long getDenominator() {
    return denominator;
  }

  /**
   * 分数加法 十字相乘计算后用新分子分母new一个实例
   */
  public Rational add(Rational rational2) {
    long n = numerator * rational2.getDenominator() + denominator * rational2.getNumerator();
    long d = denominator * rational2.getDenominator();
    return new Rational(n, d);
  }

  /**
   * 分数减法
   * */
  public Rational jian(Rational rational2) {
    long n = numerator * rational2.getDenominator() - rational2.getNumerator() * denominator;
    long d = denominator * rational2.getDenominator();
    return new Rational(n, d);
  }

  /**
   * 分数乘法
   * */
  public Rational chengFa(Rational rational2) {
    long n = numerator * rational2.getNumerator();
    long d = denominator * rational2.getDenominator();
    return new Rational(n, d);
  }

  /**
   * 分数除法
   * */
  public Rational chuFa(Rational rational2) {
    long n = numerator * rational2.getDenominator();
    long d = denominator * rational2.getNumerator();
    return new Rational(n, d);
  }

  public boolean equals(Object a) {
    if ((this.jian((Rational) (a))).getNumerator() == 0) {// 通过调用减法方法判断分子运算后是否是0
      return true;
    } else
      return false;
  }

  public int intValue() {
    return (int) doubleValue();
  }

  public float floatValue() {
    return (float) doubleValue();
  }

  public double doubleValue() {
    return numerator * 1.0 / denominator;
  }

  public long longValue() {
    return (long) doubleValue();
  }

  public int compareTo(Object o) {
    if ((this.jian((Rational) o)).getNumerator() > 0)
      return 1;
    else if ((this.jian((Rational) o)).getNumerator() < 0)
      return -1;
    else
      return 0;
  }

 @Override  
  public String toString(){//重写系统的tostring 方法
    if(denominator==1)
      return numerator+"";
    else
      return numerator+"/"+denominator;
  }
}
