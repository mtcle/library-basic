package work13;

public class TestTriangle {

  public static void main(String[] args) throws IllegalTriangelException {

    @SuppressWarnings("unused")
    Triangle test = new Triangle(1, 2, 3);
  }

}


class Triangle {
  private double a;
  private double b;
  private double c;

  public Triangle() {

  }

  public Triangle(double a, double b, double c) throws IllegalTriangelException {
    if ((a < b + c) && (b < a + c) && (c < a + b)) {
      this.a = a;
      this.b = b;
      this.c = c;
    } else
      throw new IllegalTriangelException("哈哈哈出错了！！！");
  }

  public double getA() {
    return a;
  }

  public void setA(double a) throws IllegalTriangelException {
    if (a < (this.b + this.c))
      this.a = a;
    else
      throw new IllegalTriangelException("出错了！！！");
  }

  public double getB() {
    return b;
  }

  public void setB(double b) throws IllegalTriangelException {
    if (b < (this.a + this.c))
      this.b = b;
    else
      throw new IllegalTriangelException("这个边太小了");
  }

  public double getC() {
    return c;
  }

  public void setC(double c) throws IllegalTriangelException {
    if (c < (this.a + this.b))
    this.c = c;
    else
      throw new IllegalTriangelException("这个边太小了");
  }
}


class IllegalTriangelException extends Exception {
  /**
   *继承了根类，重写了一下，也就是改了改名字 
   */
  private static final long serialVersionUID = 1L;

  public IllegalTriangelException(String str) {
    System.out.println(str);
  }

  public IllegalTriangelException() {

  }
}
