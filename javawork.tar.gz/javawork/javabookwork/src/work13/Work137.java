package work13;



public class Work137 {
  public static void main(String[] args) throws NumberFormatException {
    System.out.println(parseBinary("110110111"));
      parseBinary("113554453112");    
      parseBinary("4554455454");   
  }

  public static int parseBinary(String str) throws NumberFormatException {
    int sum = 0;

    for (int i = 0; i < str.length(); i++) {
      char ch = str.charAt(i);
      if ((ch == '0') || (ch == '1'))
        sum = sum * 2 + str.charAt(i) - 48;
      else {
        throw new NumberFormatException("出现异常了吧～～～");
      }
    }
    return sum;
  }
}
