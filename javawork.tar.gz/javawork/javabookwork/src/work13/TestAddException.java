package work13;

import java.util.Scanner;

public class TestAddException {

  public static void main(String[] args) {
    try {
      @SuppressWarnings("resource")
      Scanner input = new Scanner(System.in);
      String stra = "";
      String strb = "";
      do {
        System.out.println("Enter the first number: ");
        stra = input.next();
      } while (!isNumber(stra));
      int a = Integer.parseInt(stra);
      do {
        System.out.print("Enter the secend number:");
        strb = input.next();
      } while (!isNumber(strb));
      int b = Integer.parseInt(strb);
      System.out.printf("sum=%d ", (a + b));
    } catch (Exception ex) {
      // System.out.println("输入的数据类型错误！");
    }


  }


  public static boolean isNumber(String str) {
    try {
      Integer.parseInt(str);
      return true;
    } catch (NumberFormatException ex) {
      System.out.println("输入的数据类型错误！");
      return false;
    }
  }
}
