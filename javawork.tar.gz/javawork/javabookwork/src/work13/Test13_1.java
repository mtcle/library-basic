package work13;

public class Test13_1 {
  public static void main(String[] args) throws newException{
    if (args.length != 3) {
      System.out.println("Usage: java Calculator operand1 operator operand2");
      System.exit(0);
    }
    int result = 0;
    try {
      switch (args[1].charAt(0)) {
        case '+':
          result = parser(args[0]) + parser(args[2]);
          break;
        case '-':
          result = parser(args[0]) - parser(args[2]);
          break;
        case '*':
          result = parser(args[0]) * parser(args[2]);
          break;
        case '/':
          result = parser(args[0]) / parser(args[2]);
          break;
      }
      System.out.println(args[0] + ' ' + args[1] + ' ' + args[2] + "=" + result);
    } catch (newException e) {
     
    }
  }

  private static int parser(String str) throws newException {
    try {
      return Integer.parseInt(str);
    } catch (NumberFormatException e) {
      System.out.println("Wrong Input: " + str);
      throw new newException("wrong input");
    }
  }
}


class newException extends Exception{
  private static final long serialVersionUID = 1L;
  public newException(){
    
  }
  public newException(String str){
    super(str);
  }
}