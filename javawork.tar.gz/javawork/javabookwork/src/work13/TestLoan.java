package work13;

public class TestLoan {

  public static void main(String[] args) throws IllegalArgumentException {
    
    try{  Loan aa = new Loan(-1, -2, -1000);
      aa.setAnnualInterestRate(-5);
    } catch (IllegalArgumentException ex) 
      {
      System.out.println("你都不会好好输入？？");
    }
  }

  @SuppressWarnings("serial")
  class LoanException extends IllegalArgumentException {
    @SuppressWarnings("unused")
    private double x;

    public LoanException() {}

    public LoanException(String x) {
      System.out.println(x);
    }

    public void method(Loan aa) throws LoanException {
      try {
        // Loan aa=new Loan();
        if (aa.getAnnualInterestRate() < 0 || aa.getLoanAmount() < 0 || aa.getNumberOfYears() < 0)
          System.out.println("错误了！");
      } catch (LoanException ex) {
        System.out.println("有负值！");
      }
    }
  }
}
