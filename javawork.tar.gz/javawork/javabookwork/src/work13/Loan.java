package work13;

import java.util.Date;

public class Loan {
  private double annualInterestRate;
  private int NumberOfYears;
  private double loanAmount;
  private Date date;


  public Loan() {
    this(2.2, 1, 1000);
  }

  public Loan(double an, int nu, double loanAmount) {
    if (an > 0 && nu > 0 && loanAmount > 0) {
      this.annualInterestRate = an;
      this.NumberOfYears = nu;
      this.loanAmount = loanAmount;
      date = new Date();
    } else
      throw new IllegalArgumentException("測試測試！");
  }

  public double getAnnualInterestRate() {
    return annualInterestRate;
  }

  public void setAnnualInterestRate(double annualInterestRate) throws IllegalArgumentException {
    if (annualInterestRate > 0)
      this.annualInterestRate = annualInterestRate;
    else
      throw new IllegalArgumentException("不能赋值负数！");
  }

  public int getNumberOfYears() {
    return NumberOfYears;
  }

  public void setNumberOfYears(int numberOfYears) {
    NumberOfYears = numberOfYears;
  }

  public double getLoanAmount() {
    return loanAmount;
  }

  public void setLoanAmount(double loanAmount) {
    this.loanAmount = loanAmount;
  }

  public Date getDate() {
    return date;
  }


  public double getMonthlyPayment() {
    double aa = annualInterestRate / 1200;
    double bb = loanAmount * aa / (1 - (Math.pow(1 / (1 + aa), NumberOfYears * 12)));
    return bb;
  }

  public double getTotalPayment() {
    double aa = getMonthlyPayment() * NumberOfYears * 12;
    return aa;
  }



}
