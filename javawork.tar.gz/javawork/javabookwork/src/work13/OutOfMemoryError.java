package work13;

public class OutOfMemoryError {
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//不要运行！！！！！！！！！
  public static void main(String[] args) {
    StringBuilder test = new StringBuilder();
    @SuppressWarnings("unused")
    StringBuffer a=new StringBuffer();
    while (true) {
      test.append(new OutOfMemoryError());
    }

  }

}
