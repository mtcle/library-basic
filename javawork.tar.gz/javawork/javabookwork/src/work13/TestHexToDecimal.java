package work13;

import java.util.Scanner;

public class TestHexToDecimal {

  public static void main(String[] args) {
    @SuppressWarnings("resource")
    Scanner input = new Scanner(System.in);
    System.out.println("输入十六进制的数： ");
    String str = input.next();
    System.out.println("Decimal是： " + change(str));

  }

  public static int change(String str) throws NumberFormatException {
    int decimal = 0;
    char strToChar;
    for (int i = 0; i < str.length(); i++) {//判断十六进制的每个字符必须是在a-f，A-F，0-9之间的，否则抛出异常
      if ((str.charAt(i) >= 'a' && str.charAt(i) <= 'f')
          || (str.charAt(i) >= '0' && str.charAt(i) <= '9')
          || (str.charAt(i) >= 'A' && str.charAt(i) <= 'F')) {
         strToChar = str.charAt(i);
      }
      else
        {throw new NumberFormatException("你输入的不是十六进制的数值！");}
      
      decimal = decimal * 16 + hexCharToDecimal(strToChar);//从高位到低位，依次乘与16，下移一位就将上次的结果×16后加上本位
    }
    return decimal;
  }

  public static int hexCharToDecimal(char a) {
    if (a >= 'A' && a <= 'Z') {
      return 10 + a - 'A';
    } else
      return a - '0';
  }


}
