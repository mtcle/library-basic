package work13;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TestArray100 {

  public static void main(String[] args) {
    int[] aa=new int[100];
    for(int i=0;i<100;i++){
      aa[i]=(int)(Math.random()*100);
    }
   try{ System.out.println("Enter a number: ");
    @SuppressWarnings("resource")
    Scanner input=new Scanner(System.in);
    int x=input.nextInt();
    System.out.println(aa[x]);}
    catch (ArrayIndexOutOfBoundsException ex){
      System.out.println("你下标越界了！");
    }
   catch(InputMismatchException ex2){
     System.out.println("输入的格式不对！");
   }
  }

}
