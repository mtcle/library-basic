package work2;

import java.util.*;

public class Javawork5 {

  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.print("Enter the subtotal and a gratuity rate:");
    float moneyTotal = input.nextFloat();
    float rateGet = input.nextFloat();
    System.out.print(("The gratuity is " + (int) ((moneyTotal * rateGet / 100) * 100) / 100.0
        + " and total is " + (int) ((moneyTotal * rateGet / 100 + moneyTotal) * 100) / 100.0));
  }

}
