package work2;
import java.util.*;
public class Javawork4 {
  public static void main(String[] args) {
    System.out.print("Enter a number in pounds:");
      Scanner input=new Scanner(System.in);
      float pound=input.nextFloat();
    System.out.print(pound+"pounds is "+(pound*0.454)+"kilograms");}
   
  }

