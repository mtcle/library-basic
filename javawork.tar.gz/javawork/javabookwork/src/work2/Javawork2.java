package work2;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Javawork2 {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.println("Enter the radius and length of a cylinder:");
    double r = input.nextDouble();
    double h = input.nextDouble();
    double s = r * r * Math.PI;
    double v = s * h;
    //这是格式化输出方法 不过不行
    // String parten = "#.#";
    // DecimalFormat decimal = new DecimalFormat(parten);
    // String str= decimal.format(v);
    //#########################
    System.out.println("the area is" + (int) (s * 10000) / 10000.0);
    System.out.println("The volume is " + Math.round(v * 10) / 10.0);
  }
}
