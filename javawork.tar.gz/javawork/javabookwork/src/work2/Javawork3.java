package work2;
import java.util.Scanner;
public class Javawork3 {
  public static void main(String[] args) {
    Scanner input =new Scanner(System.in);
    System.out.print("Enter a value for feet:");
    double feet=input.nextDouble();
    System.out.print(feet+"feet is "+(int)((feet/0.35)*100)/100.0+"meters");

  }

}
