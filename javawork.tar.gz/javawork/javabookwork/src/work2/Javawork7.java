package work2;
import java.util.*;
public class Javawork7 {
  /**
   by mtcle pm6:46
   */
  public static void main(String[] args) {
   Scanner input = new Scanner (System.in);
   System.out.print("Enter the nmber of minutes:");
   double mins=input.nextDouble();
   int years;
   int days;
   years=(int)mins/(60*24*365);
   days=(int)((mins-years*365*24*60)/(24*60));
//   System.out.print(mins+"minutes is approximately "+years+"and"+days+"days");
   String aa=String.format("%1.0f minutes is approximately %d and %d days", mins,years,days);/*运用格式化输出方式降低内存占用,%f=float,%d=int,后面的为参数
   1.0代表精确位数*/
   System.out.print(aa);

  }

}
