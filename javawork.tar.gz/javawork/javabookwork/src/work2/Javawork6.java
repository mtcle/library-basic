package work2;
import java.util.Scanner;
public class Javawork6 {

  /*by mtcle*/
  public static void main(String[] args) /*String[]是接收控制台输入的参数的*/{
   System.out.print("Enter a number between 0 and 1000:");
   Scanner input=new Scanner(System.in);//input是对象，new一下后变成？？？
   int numberGet=input.nextInt();
   int sum=0;  
if (numberGet>0 && numberGet<1000){
     int h,t,o;
     if (numberGet>=100){
     h=(int)(numberGet/100);
     t=(int)((numberGet-h*100)/10);
     o=numberGet-h*100-t*10;
     sum=h+t+o;
     System.out.print("The sum of the digits is "+sum);}
     else if (numberGet>=10){
     t=(int)(numberGet/10);
     o=numberGet-t*10;
     System.out.print("The sum of the digits is "+sum);}
     else {System.out.print(numberGet);}
}
else
{ System.out.print("wrong");}
  }
}