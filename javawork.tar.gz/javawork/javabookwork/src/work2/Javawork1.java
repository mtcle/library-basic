package work2;
import java.util.*;
public class Javawork1 {
	public static void main(String[] args) {
    Scanner input=new Scanner(System.in);
	  System.out.print("Enter a degree in Celsius:");
	  float i=input.nextFloat();
	  System.out.println(i+" Celsius is "+(9.0/5*i+32)+" Fathrenheit");
	}

}
