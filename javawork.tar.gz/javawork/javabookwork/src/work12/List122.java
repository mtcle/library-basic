package work12;

import javax.swing.JButton;
import javax.swing.JFrame;

public class List122 {

  public static void main(String[] args) {
   JFrame frame=new JFrame("first frame");
   JButton button=new JButton("first button");
   frame.add(button);
   
   frame.setSize(500, 600);
   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   frame.setLocationRelativeTo(null);//
   frame.setVisible(true);
  }

}
