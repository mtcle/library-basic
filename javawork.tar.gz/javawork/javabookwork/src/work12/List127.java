package work12;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class List127 {
  public static void main(String[] args) {
   TestSwingCommonFeatures frame=new TestSwingCommonFeatures();
   frame.setTitle("test of common features");
   frame.setSize(300, 150);
   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   frame.setVisible(true);
   frame.setLocationRelativeTo(null);   
   
  }

}
class TestSwingCommonFeatures extends JFrame{
  private static final long serialVersionUID = -7364439603446212073L;

public TestSwingCommonFeatures(){
   JPanel p1=new JPanel(new FlowLayout(FlowLayout.LEFT,2,3));
   JButton jbleft=new JButton("left");
   JButton jbright=new JButton("right");
   JButton jbcenter=new JButton("center");
   jbleft.setBackground(Color.red);
   jbright.setToolTipText("this is a tip");
   jbcenter.setForeground(Color.green);
   p1.add(jbleft);
   p1.add(jbcenter);
   p1.add(jbright);
   p1.setBorder(new TitledBorder("there have three buttons"));
   Font largeFont=new Font("TimesRoman",Font.BOLD,20);
   Border lineBorder=new LineBorder(Color.BLACK,2);
   JPanel p2=new JPanel(new GridLayout(1,2,5,5));
   JLabel jlabelred=new JLabel("red");
   JLabel jlabelorange=new JLabel("orange");
   jlabelred.setFont(largeFont);
   jlabelorange.setFont(largeFont);
   jlabelred.setForeground(Color.red);
   jlabelorange.setForeground(Color.orange);
   jlabelorange.setBorder(lineBorder);
   jlabelred.setBorder(lineBorder);
   p2.add(jlabelred);
   p2.add(jlabelorange);
   p2.setBorder(new TitledBorder("two labels"));
   setLayout(new GridLayout(2,1,5,5));
   add(p1);
   add(p2);     
 }
}