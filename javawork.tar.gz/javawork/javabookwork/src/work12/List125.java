package work12;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class List125 {

  /**
   * @param BorderLayout
   */
  public static void main(String[] args) {
    ShowBorderLayout frame =new ShowBorderLayout();
    frame.setTitle("borderlayout test");
    frame.setSize(300,200);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
    frame.setLocationRelativeTo(null);    
  }
}

class ShowBorderLayout extends JFrame{
  private static final long serialVersionUID = 1L;
  public ShowBorderLayout(){
    setLayout(new BorderLayout(5,10));//水平间距，垂直间距
    add(new JButton("east"),BorderLayout.EAST);
    add(new JButton("south"),BorderLayout.SOUTH);
    add(new JButton("west"),BorderLayout.WEST);
//    add(new JButton("north"),BorderLayout.NORTH);
    add(new JButton("center"),BorderLayout.CENTER);
  }
}