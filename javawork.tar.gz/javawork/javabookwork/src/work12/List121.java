package work12;

import javax.swing.JApplet;
import javax.swing.JFrame;

public class List121 {

  public static void main(String[] args) {
    JFrame frame=new JFrame("first frame");
    frame.setSize(400, 500);
    frame.setLocationRelativeTo(null);//确定和特定组件相关的框架的位置，null为中间
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//关闭的行为
    frame.setVisible(true);//初始话是为不可见

  }

}
