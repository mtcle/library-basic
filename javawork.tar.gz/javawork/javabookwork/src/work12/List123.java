package work12;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class List123 {

  /**
   * @param ShowFlowLayOut流式布局
   */
  public static void main(String[] args) {
   ShowFlowLayOut frame=new ShowFlowLayOut();
   frame.setTitle("hello java");
   frame.setSize(200,200);
   frame.setLocationRelativeTo(null);
   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   frame.setVisible(true);

  }

}


class ShowFlowLayOut extends JFrame{
  public ShowFlowLayOut(){
  setLayout(new FlowLayout(FlowLayout.LEFT,10,20));
  add(new JLabel("first label"));
  add(new JTextField(8));
  add(new JLabel("second label"));
  add(new JTextField(1));//数字代表文本框的长度
  add(new JLabel("last label"));
  add(new JTextField(7));
  }
  
}