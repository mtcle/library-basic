package work12;

import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class List124 {

  /**
   * @param ShowGridLayout 网格布局
   */
  public static void main(String[] args) {
   ShowGridLayOut frame=new ShowGridLayOut();
   frame.setTitle("GridLayout");
   frame.setSize(200, 150);
   frame.setLocationRelativeTo(null);
   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   frame.setVisible(true);
   

  }

}

class ShowGridLayOut extends JFrame{
  
  private static final long serialVersionUID = 1L;

  public ShowGridLayOut(){
    setLayout(new GridLayout(3,2,5,5));//参数依次为行数，列数，列水平距，行水平距
    add(new JLabel("first label"));
    add(new JTextField(8));
    add(new JLabel("second label"));
    add(new JTextField(1));//数字代表文本框的长度
    add(new JLabel("last label"));
    add(new JTextField(7));
  }
}