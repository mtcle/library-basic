package work12;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class List126 {

  /**
   * @param TestOfPanels
   */
  public static void main(String[] args) {
    TestPanels frame = new TestPanels();
    frame.setTitle("test of panel");
    frame.setSize(400, 250);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
  }

}


class TestPanels extends JFrame {//定义一个继承JFrame的类，该类是个容器类
  private static final long serialVersionUID = 3217112103266026009L;

  public TestPanels() {
    JPanel p1 = new JPanel();//new一个JPanel面板对象  
    p1.setLayout(new GridLayout(4, 3));//设置面板对象的输出形式为grid的
    for (int i = 1; i <= 9; i++) {
      p1.add(new Button("  " + i));//对这个面板对象增加对象    
    }
    p1.add(new Button("  " + 0));//同上
    p1.add(new Button("start"));
    p1.add(new Button("stop"));
    
    

    JPanel p2 = new JPanel(new BorderLayout());//new一个面板对象，面板的布局形式为border形式  
    p2.add(new JTextField("time is in here"),BorderLayout.NORTH);//给border添加一个Jtextfield
    p2.add(p1, BorderLayout.CENTER);//把面板对象p1增加到p2
    add(p2, BorderLayout.EAST);//把整个p2增加到borderlayout的东区
    add(new Button("foot is here"), BorderLayout.CENTER);//增加一个区按钮
//    add(new Button("test"),BorderLayout.WEST);
  }
}
