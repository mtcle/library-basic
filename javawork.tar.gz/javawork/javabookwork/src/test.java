import java.util.Date;

public class test {

  public static void main(String[] args) throws Exception {
//   try{ Sequence a = new Sequence();
//    // System.out.println(a.getSequence());
//    System.out.println(a.toString());
//    System.out.println(a.toString());
//    System.out.println(a.toString());
//
//
//    Rent sss = new Rent();
//    System.out.println(sss.getRentPrice(5));
//   }catch (Exception ex){System.out.println("sssss");}

//  System.out.println(dd.getTime());
  
  Book aaa=new Book("sdfsdf");
  System.out.println("+++++++++++");
  aaa.newRecord();
  System.out.println("---------------");
  aaa.record.add(aaa.newRecord());
  System.out.println(aaa.record.size());
  }
}
