package hard;

import java.io.File;
import java.util.Scanner;

public class TestRead {
  String temp;
  static String print;
  static int state = 0;//标记关键词高亮状态
  static int block=0;//标记块的状态0代表显示
  static int constant=0;//标记行注释状态0代表能显示

  public static void main(String[] args) throws Exception {

    toHtml();
  }

  public static void toHtml() throws Exception {
    File file = new File("javaToHtml.html");
    // if (file.exists()) {
    // System.out.println("已经有个同名文件了!");
    // System.exit(0);
    // }
    java.io.PrintWriter output = new java.io.PrintWriter(file);
    read();
    /**
     * 处理文本查找单词
     */
    Txt docChuLi = new Txt(print);// 整个文本
    docChuLi.getWordsArray();
    System.out.println("文件单词总数" + docChuLi.getSum());
    System.out.println("关键词：" + docChuLi.keywords.length);
    // for (int p = 0; p < docChuLi.getSum(); p++) {
    // System.out.println(docChuLi.getWordsArray()[p]);
    // }
    output.print("<html>");
    output.print("<pre>");
    for (int i = 0; i < docChuLi.getSum(); i++) {
      if (docChuLi.panduan(docChuLi.getWordsArray()[i]) && (state == 0)) {//
        output.print("<font color=\"blue\">");
        output.print("<strong>");
        output.print(docChuLi.getWordsArray()[i]);
        output.print("</strong>");
        output.print("</font>");
      } else if (docChuLi.getWordsArray()[i].equals("begin")) {
        output.print("<font color=\"green\">");
        state = 1;// 标识出现了前半部分
//        constant=1;
        output.print("//");
      } else if (docChuLi.getWordsArray()[i].equals("end")) {
        // System.out.println("结束了！");
        output.print("</font>");
        state = 0;// 改写高亮字状态
        constant=0;
      } else if (docChuLi.getWordsArray()[i].equals("blockbegin")) {
        // System.out.println("进到块注释里了");
        output.print("<font color=\"pink\">");
        state = 1;
        output.print("/**");
        

      }else if  (docChuLi.getWordsArray()[i].equals("blockbegin1")) {
        output.print("<font color=\"pink\">");
        state = 1;
        output.print("*");
        }
      else if (docChuLi.getWordsArray()[i].equals("end")) {
        output.print(" ");
      } else if (docChuLi.getWordsArray()[i].equals("blockend")) {
        state = 0;
        output.print("<font color=\"pink\">");
        output.print("*/");
        output.print("</font>");
      } else if (docChuLi.getWordsArray()[i].equals("constantBegin")) {

        // System.out.println("进到常量里面了");
        output.print("<font color=\"blue\">");
        output.print("\"");
        state = 0;

      } else if (docChuLi.getWordsArray()[i].equals("others")) {
        output.print("\\\"");
      } else if (docChuLi.getWordsArray()[i].equals("constantEnd")) {
        state = 1;
        output.print("\"");
        output.print("</font>");
      } else {
        output.print(docChuLi.getWordsArray()[i]);
      }
    }
    output.print("</pre>");
    output.print("</html>");
    output.close();
  }

  public static String[] read() throws Exception {
    File file = new File("test.java");
    StringBuilder a = new StringBuilder();
    StringBuilder temp = new StringBuilder();
    @SuppressWarnings("resource")
    Scanner input = new Scanner(file);
    while (input.hasNext()) {
      String temp1 = input.nextLine().replaceAll("//", "begin");    
      String temp2 = temp1.replace("/**", " blockbegin ");
      String temp3 = temp2.replace("*/", " blockend ");
      String temp4 = temp3.replaceFirst("\"", " constantBegin ");
      String temp5 = temp4.replaceAll("\\\\\"", " others ");
      String temp6 = temp5.replaceFirst("\"", " constantEnd ");
      String temp7 = temp6.replaceFirst("\\*", " blockbegin1 ");
      String temp8=temp7.replaceAll("<", "&lt");
      String temp9=temp8.replaceAll(">", "&gt");
      a.append(temp9);
      a.append(" end ");
      a.append("<p>");
    }
    print = a.toString();// 产生了无格式文本了
    String word = temp.toString();
    String wordArray[] = word.split("[\\s\\d\\p{Punct}]+");
    // System.out.println("单词长度：" + wordArray.length);
    return wordArray;
  }



}
