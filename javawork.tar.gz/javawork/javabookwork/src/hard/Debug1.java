package hard;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Debug1 {
  public static void main(String[] args) {
    Pattern p;
    Matcher m;
    String s1 = "// System.out.println(\"words1 \" + (i + 1) + \":\" + words1[i]);";

     p = Pattern.compile("\\W+");
    /**
     * words4 1:// 
     * words4 2:. 
     * words4 3:. 
     * words4 4:(" 
     * words4 5: " + ( 
     * words4 6: + 
     * words4 7:) + ":" +
     * words4 8:[ 
     * words4 9:]);k
     */
    
//    p = Pattern.compile("\\w+");
    /**
     * words4 1:System
     * words4 2:out
     * words4 3:println
     * words4 4:words1
     * words4 5:i
     * words4 6:1
     * words4 7:words1
     * words4 8:i
     */
    
//    p = Pattern.compile("\\s+");
    /**
     * words4 1: 
     * words4 2: 
     * words4 3: 
     * words4 4: 
     * words4 5: 
     * words4 6: 
     * words4 7: 
     * words4 8: 
     * words4 9: 
     * words4 10: 
     */
//    p = Pattern.compile("\\w+|\\s+|\\W+");
    m = p.matcher(s1);
    String[] words4 = new String[s1.length()];
    int n = 0;
    while (m.find()) {
      words4[n] = m.group();
      n++;
    }
    for (int i = 0; i < n; i++) {
      System.out.println("words4 " + (i + 1) + ":" + words4[i]);
    }
  }
}