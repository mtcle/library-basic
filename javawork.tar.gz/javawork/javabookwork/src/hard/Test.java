package hard;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Test {

  public static void main(String[] args) throws Exception {
    File file=new File("temp1.dat");
   java.io.PrintWriter output=new java.io.PrintWriter(file);
   output.println("hello");
   output.println("world");
   output.println(100);
   output.close();
      
    

  }

}
