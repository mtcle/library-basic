package hard;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


 class Txt {
  private String oldStr = "hello world case 123 456";
//  private String newStr;
  public String[] keywords = {"abstract", "assert", "boolean", "break", "byte", "case", "catch",
      "char", "class", "const", "continue", "default", "do", "double", "else", "enum", "extends",
      "for", "final", "finally", "float", "goto", "if", "implements", "import", "instanceof",
      "int", "interface", "long", "native", "new", "package", "private", "protected", "public",
      "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this", "throw",
      "throws", "transient", "try", "void", "volatile", "while", "true", "false", "null","out"};
  private String keyword;
  private int sum=0;

  public Txt(String str) {
    this.oldStr = str;
  }



//  public String getNewStr() {
//    return newStr;
//  }
//
//
//
//  public void setNewStr(String newStr) {
//    this.newStr = newStr;
//  }



  public void htmlToJava() {


  }

  public void changeToBule(String str) {

  }

  public void changeToHighBule() {// keywords


  }

  public void changeToGreen(String str) {

  }

  public boolean panduan(String str) {// 判断是否是关键词
    for (int i = 0; i < keywords.length; i++) {
      if (keywords[i].equals(str)) return true;
    }
    return false;

  }

  public String getKeyword() {
    return keyword;
  }



  public void setKeyword(String keyword) {
    this.keyword = keyword;
  }



  public int getSum() {
    return sum;
  }



  public void setSum(int sum) {
    this.sum = sum;
  }



  public String[] getKeywords() {
    return keywords;
  }



  public String getOldStr() {
    return oldStr;
  }



  public void setOldStr(String oldStr) {
    this.oldStr = oldStr;
  }

  
  public String[] getWordsArray(){
    Pattern p;
    Matcher m;
    p = Pattern.compile("\\w+|\\s+|\\W+");
    m = p.matcher(oldStr);
    String[] words4 = new String[oldStr.length()];
    int n = 0;
    while (m.find()) {
      words4[n] = m.group();
      n++;
    }
//    for (int i = 0; i < n; i++) {
//      System.out.println("words4 " + (i + 1) + ":" + words4[i]);
//    }
  
  sum=n;
//  System.out.println("sum:"+n);
  return words4;
  }

}
