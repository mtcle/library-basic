package hard;

import java.io.File;
import java.util.Scanner;

public class test123 {

  /**
   * @param args
   */
  public static void main(String[] args) {
//    String a=" ___<p>public static String[] read() throws Exception{File file=new File(test.java);StringBuilder a=new StringBuilder();";

//    String[]b=a.split("[\\s\\d\\p{Punct}]+");
//    String[]b=a.split("[%\\+\\-\\*/\r\n\t \\[\\].;(){},]",2);
//    StringBuilder c=new StringBuilder();
//    for(int i=0;i<b.length;i++){
//    System.out.println(b[i]);}
//  }

 Txt test=new Txt("ds12/\"sddsd");
 test.getWordsArray();
 System.out.println(test.getSum());
 System.out.println(test.getKeywords()[2]); 
//  System.out.println(test.);
  String aa="*kasdjfkj\"sdfjkhk ajd";
  System.out.println(aa.replaceAll("\\*", "+++"));
  
  
}
}