package work1;

public class Message_five {

	/**
	 1.2 javawork
	 @mtcle 
	 */
	public static void main(String[] args) {
		int i;
		for(i=1;i<=5;i++)//
			{System.out.println("Welcome to Java");}
	}

}
