package work1;

public class Messageprint {

	/**
	 * @mtcle the first javawork
	 */
	public static void main(String[] args) {
		System.out.println("Welcome to Java");// print first
		System.out.println("Welcome to computer Science");//print second
		System.out.println("Programming is fun");//print last
	}

}
