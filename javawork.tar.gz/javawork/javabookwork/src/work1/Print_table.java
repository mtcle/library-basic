package work1;

public class Print_table {

	/**
	 * javawork1.4 @mtcle
	 */
	public static void main(String[] args) {
		int i = 1;
		System.out.println("a\ta^2\ta^3");
		for (i = 1; i <= 4; i = i + 1) {
			System.out.print(i + "\t");
			System.out.print(i * i + "\t");
			System.out.println(i * i * i + "\t");// 运用制表符\t非常方便的运用
		}
	}
}
