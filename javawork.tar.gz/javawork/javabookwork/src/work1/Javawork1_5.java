package work1;

public class Javawork1_5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("9.5x4.5-2.5x3/45.5-3.5=" + (9.5 * 4.5 - 2.5 * 3)
				/ (45.5 - 3.5));
	}

}
