package work1;

public class Javawork1_6 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i=1,sum=0;
		while(i<10){
				sum=sum+i;
				i++;
			}
			System.out.println("1+2+3+..+9="+sum);// TODO Auto-generated method stub

	}

}
