package work1;

public class Javawork1_7b {

	/**
	 * use for
	 */

	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		double i = 1, sum = 0;
		int n = 99999999;
		for (i = 1; i < (2 * n + 1); i = i + 2) {
			sum = sum + (1.0 / (2 * i - 1) - 1.0 / (2 * i + 1));
		}

		long stop = System.currentTimeMillis();
		System.out.println(4 * sum + "耗时" + (stop - start));
	}

}
