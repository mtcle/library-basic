package work1;

public class Javawork1_7 {

	/**
	 use while
	 */
	public static void main(String[] args) {
		double sum=0,n=99999999;//这里要输入的n为偶数
		while(n>=1){
			sum=sum+(1.0/(2*n-1)-1.0/(2*n+1));
			n=n-2;}
			System.out.println("PI="+4*sum);}
	}


