package work3;

import java.util.Scanner;

public class TestPrintCalender {//测试类
  public static void main(String[] args) {
    Scanner input=new Scanner(System.in);
    System.out.println("请输入你要查看的年份和月份空格隔开：");
    int year=input.nextInt();
    int month=input.nextInt();
   Calendar test=new Calendar(year, month);    
   test.printMonthTitle();
   test.printMonthBody();
  }

}





class Calendar{
private int year;
private int month;

public Calendar(int year,int month){
  this.year=year;
  this.month=month;
}

public int getYear() {
  return year;
}

public void setYear(int year) {
  this.year = year;
}

public int getMonth() {
  return month;
}

public void setMonth(int month) {
  this.month = month;
}
public  void printMonthTitle() // 打印日历抬头
{
  System.out.println("            \t " +this.year + " 年 " + this.month + " 月的月历");
  System.out.println("--------------------------------------------------");
  System.out.println("Sun\tMon\tTue\tWed\tThu\tFri\tSat");
}
public void printMonthBody() // 打印日历内容
{
  int startday = getStartDay();
  int monthDaysTotal = getNumberOfDaysInMonth();
  int i = 0;
  for (i = 0; i <startday; i++) {
   System.out.print("        ");// 打印日历开始的空白
  
  }
  for (i = 1; i <= monthDaysTotal; i++)// 打印数字
  {
//    if (i<10) 
    System.out.print(i+"\t");// 打印天数
//    else
//      ss.append(i+"     ");
    if ((i + startday) % 7 == 0) {
      System.out.println("");
     
    }// 处理换行问题
  }
  System.out.println();  
}
public int getStartDay( )// 获取日历该月第一天的开头日期
{
  final int YUAN1800_1_1 = 3;// 定义一个初始的月份的1800.1.1为星期三的常量
  int monthDaysTotal = getTotalDays();
  return (monthDaysTotal + YUAN1800_1_1) % 7;// 和其实位置相加后除7求余？？？
}
public int getTotalDays() {
  int total = 0, i;
  for (i = 1800; i < this.year; i++) {
    if (isLeapYear())// 判断润年否
    {
      total = total + 366;
    } else {
      total = total + 365;
    }// 计算到了该年之前的天数
  }
  for (i = 1; i < this.month; i++) {
    total = total + getNumberOfDaysInMonth();
  }
  return total;
}
public int getNumberOfDaysInMonth()// 获取该月天数
{
  if (this.month == 1 || this.month == 3 || this.month == 5 || this.month == 7 || this.month == 8 || this.month == 10
      || this.month == 12) {
    return 31;
  } else if (this.month == 2) {
    if (isLeapYear())
      return 29;
    else
      return 28;
  } else
    return 30;
}
public  boolean isLeapYear()// 判断是否是润年
{
  return this.year % 400 == 0 || (this.year % 100 != 0 && this.year % 4 == 0);
}
public  String getMonthName() {
  String monthName = " ";
  switch (this.month) {
    case 1:
      monthName = "yi1";
      break;
    case 2:
      monthName = "yi2";
      break;
    case 3:
      monthName = "yi3";
      break;
    case 4:
      monthName = "yi4";
      break;
    case 5:
      monthName = "yi5";
      break;
    case 6:
      monthName = "yi6";
      break;
    case 7:
      monthName = "yi7";
      break;
    case 8:
      monthName = "yi8";
      break;
    case 9:
      monthName = "yi9";
      break;
    case 10:
      monthName = "yi10";
      break;
    case 11:
      monthName = "yi11";
      break;
    case 12:
      monthName = "yi12";
      break;
  }
  return monthName;
}
}
