package work3;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class TestPrintCalendarOOP {


  public static void main(String[] args) {
    Calendar test = new GregorianCalendar();
    Print aa = new Print();
    System.out.println("输入年份月份空格隔开： ");
    @SuppressWarnings("resource")
    Scanner input = new Scanner(System.in);
    int year = input.nextInt();
    int month = input.nextInt();
    aa.setMonth(month);
    aa.setYear(year);
    test.set(year, month, 0);
    aa.printMonthTitle();
    aa.printMonthBody(test.get(Calendar.DAY_OF_WEEK) - 1,
        test.getActualMaximum(Calendar.DAY_OF_MONTH));
  }



}


class Print {
  private int year;
  private int month;

  public void setYear(int year) {
    this.year = year;
  }

  public void setMonth(int month) {
    this.month = month;
  }

  public void printMonthTitle() // 打印日历抬头
  {
    System.out.println("     \t " + this.year + " 年 " + this.month + " 月的月历");
    System.out.println("--------------------------------------");
    System.out.println("  Sun Mon Tue Wed Thu Fri Sat");
  }


  public void printMonthBody(int startday, int numberdays) // 打印日历内容
  {

    for (int i = 0; i < startday; i++) {
      System.out.print("    ");// 打印日历开始的空白
    }
    for (int i = 1; i <= numberdays; i++)// 打印数字
    {
      System.out.printf("%4d", i);// 打印天数
      if ((i + startday) % 7 == 0) System.out.println();// 处理换行问题
    }
    System.out.println();
  }
}
