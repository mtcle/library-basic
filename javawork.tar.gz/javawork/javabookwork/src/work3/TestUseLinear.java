package work3;

import java.util.Scanner;
import work3.Linear;
public class TestUseLinear {

  /**
   * @param args
   */
  public static void main(String[] args) {
    System.out.print("第一个坐标：");
    Scanner inputa=new Scanner(System.in);
//    Scanner inputb=new Scanner(System.in);
//    Scanner inputc=new Scanner(System.in);
//    Scanner inputd=new Scanner(System.in);
    double a=inputa.nextDouble();
    double b=inputa.nextDouble();
    double c=inputa.nextDouble();
    double d=inputa.nextDouble();
    System.out.print("第二个坐标：");
//    Scanner inpute=new Scanner(System.in);
//    Scanner inputf=new Scanner(System.in);
//    Scanner inputg=new Scanner(System.in);
//    Scanner inputh=new Scanner(System.in);
    double e=inputa.nextDouble();
    double f=inputa.nextDouble();
    double g=inputa.nextDouble();
    double h=inputa.nextDouble();
    
    double B=c-a;
    double A=b-d;
    double E=c*b-a*d;
    double D=g-e;
    double C=f-h;
    double F=f*g-e*h;
  Linear test=new Linear(A,B,C,D,E,F);
  System.out.print(test.getX()+" "+test.getY());
  }

}

