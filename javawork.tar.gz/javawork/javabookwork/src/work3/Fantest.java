package work3;

public class Fantest {

  /**
   * @param args
   */
  public static void main(String[] args) {
    Fan fan1=new Fan();
    Fan fan2=new Fan();
    fan1.setSpeed(3);
    fan1.setColor("yellow");
    fan1.setOn(true);
    fan1.setRadius(10);
    fan2.setOn(false);
    fan2.setSpeed(2);
    fan2.setColor("blue");
    fan2.setRadius(5);
    System.out.println("fan1的信息: "+fan1.toString());
    System.out.println("fan2的信息: "+fan2.toString());
  }

}
class Fan{
  final int SLOW=1;
  final int MEDIUM=2;
  final int FAST=3;
  private int speed=SLOW;
  private boolean on=false;
  private double radius=5;
  private String color="blue";
  public int getSpeed() {
    return speed;
  }
  public void setSpeed(int speed) {
    this.speed = speed;
  }
  public boolean isOn() {
    return on;
  }
  public void setOn(boolean on) {
    this.on = on;
  }
  public double getRadius() {
    return radius;
  }
  public void setRadius(double radius) {
    this.radius = radius;
  }
  public String getColor() {
    return color;
  }
  public void setColor(String color) {
    this.color = color;
  }
  public Fan(){//无参构造方法
    
  }
 public String toString(){
   StringBuilder str=new StringBuilder();
   if (on==false){
//     System.out.print("fan is off!");
      str.append(" 颜色 "+color);
      str.append(" 半径 "+radius);      
   }
   else {str.append("fan is off!\n"+"速度: "+speed+" 颜色: "+color+"半径： "+radius);
   }
   return  str.toString();
 } 
}