package work3;
import java.util.*;
public class TestGregorianCalendar {
  public static void main(String[] args) {
   long aa=1234567898765l;
   GregorianCalendar a=new GregorianCalendar();
   int year=a.get(GregorianCalendar.YEAR);//获得当前日期
   int month=a.get(GregorianCalendar.MONTH);
   int day=a.get(GregorianCalendar.DAY_OF_MONTH);
   System.out.println(year+"\t"+month+"\t"+day);
//   a.setTimeInMillis(aa);//这个就相当于改变了系统时间值了
//   int year2=a.get(GregorianCalendar.YEAR);//获得当前系统时间，是已经改变后的了
//   int month2=a.get(GregorianCalendar.MONTH);
//   int day2=a.get(GregorianCalendar.DAY_OF_MONTH);
//   System.out.print(year2+"\t"+month2+"\t"+day2);
  }
}

