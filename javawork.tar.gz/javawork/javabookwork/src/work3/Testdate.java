package work3;

import java.util.Date;
import java.util.Scanner;


public class Testdate {

  /**
   * @param args
   */
  public static void main(String[] args) {
    Scanner input=new Scanner(System.in);
    System.out.println("Enter the number:");
    long a=input.nextLong();
   Date temp=new Date(a);
//   StringBuffer str=new StringBuffer();
   System.out.print("该时间是："+temp);//toString()有什么用？
  }

  
}

