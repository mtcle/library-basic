package work3;

import java.util.Scanner;

public class TestAtm {
  static int choice = 0;
  static int xx;

  /**
   * @param args
   */
  public static void main(String[] args) {
    // TODO Auto-generated method stub
    Account[] a = new Account[10];// 创建一个10个对象的数组，默认为null，没有对象要在下面赋值
    for (int i = 0; i < 10; i++) {
      a[i] = new Account(i, 100.0);// 必须要实例化一个对象，用实例化的对象对数组赋值
    }
    do {
      System.out.println("输入0-9之间的id：");
      @SuppressWarnings("resource")
      Scanner input = new Scanner(System.in);
      choice = input.nextInt();
    } while (choice >= 10 || choice < 0);



    if (choice >= 0 && choice < 10) {
      do {
        do {
          menu();
          // System.out.println("Enter your choice: ");
          @SuppressWarnings("resource")
          Scanner inputx = new Scanner(System.in);
          int xx = inputx.nextInt();
          switch (xx) {
            case 1:

              System.out.println("你的账户余额： "+a[choice].getBalance());
              break;
            case 2:

              System.out.println("输入要取的钱： ");
              double ss = inputx.nextDouble();
              if (a[choice].getBalance() < ss) {
                System.out.println("余额不足，取钱错误！");
              } else {
                a[choice].withDraw(ss);
                System.out.println(a[choice].getBalance());
              }
              break;
            case 3:
              System.out.println("输入要存的钱： ");
              double bb = inputx.nextDouble();
              a[choice].deposit(bb);
              System.out.println(a[choice].getBalance());
              break;
            case 4:
              break;
          }
        } while (xx != 4);
      } while (choice < 0 || choice >= 10);

    } else
      System.out.println(" ");
  }

  public static void menu() {
    System.out.println("Main menu");
    System.out.println("1:check balance");
    System.out.println("2:withdraw");
    System.out.println("3:deposit");
    System.out.println("4:exit");
    System.out.println("Enter a choice:");
  }
}
