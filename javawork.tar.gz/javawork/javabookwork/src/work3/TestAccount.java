package work3;

import java.util.Date;

public class TestAccount {

  public static void main(String[] args) {
    Account a = new Account(1, 100);
  }


  /**
   * // * @param args //
   */
  // public static void main(String[] args) {
  // Account mtcle=new Account(1122,20000.0,0.0045,null);
  // System.out.println(mtcle.getBalance());
  // mtcle.withDraw(2500);
  // System.out.println(mtcle.getBalance());
  // mtcle.deposit(3000);
  // System.out.println(mtcle.getBalance());
  // System.out.printf("余额：%.1f利率：%.2f 日期：%s",mtcle.getBalance(),mtcle.getAnnualInterestRate()*100,mtcle.getDate());
  // // System.out.println(mtcle.getDate());
  // }
  //
}


class Account {
  private int id;
  private double balance;
  private double annualInterestRate;
  private Date dateCreated;

  // int a=22;
  // static int b=33;

  // {
  // a=1; //定义初始化数据块
  // b=2;
  // }

  public Account(int id, double balance, double annualInterestRate, Date dateCreated) { // 构造方法
    this.id = id;
    this.annualInterestRate = annualInterestRate;
    this.dateCreated = dateCreated;
    this.balance = balance;
    // System.out.println(b);
    // System.out.println(a);
  }

  public Account(int id, double balance) {
    this.id = id;
    this.balance = balance;
  }

  public int getId() {
    return id;
  }

  public double getBalance() {
    return balance;
  }

  public double getAnnualInterestRate() {
    return annualInterestRate;
  }

  public void setId(int id) {
    this.id = id;
  }

  public void setBalance(double balance) {
    this.balance = balance;
  }

  public void setAnnualInterestRate(double AnnualInterestRate) {
    this.annualInterestRate = AnnualInterestRate;
  }

  public String getDate() {
    Date dateCreated = new Date();
    this.dateCreated = dateCreated;
    return dateCreated.toString();
  }

  public double getMonthlyInterestRate() {
    return annualInterestRate;
  }

  public double withDraw(double a) {// 从特定账户提取特定金额
    if (a <= balance) {
      balance = balance - a;
      return balance;
    } else
      return -1;
  }

  public double deposit(double a) {// 给账户存钱
    balance = balance + a;
    return balance;
  }
  //
  // @Override
  // public toString(){
  //
  // }


}
