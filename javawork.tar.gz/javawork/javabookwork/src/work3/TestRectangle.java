package work3;

public class TestRectangle {// 测试类

  /**
   * @param args
   */
  public static void main(String[] args) {

    Rectangle a=new Rectangle();
    Rectangle b=new Rectangle();
    System.out.println("a的面积： "+a.getArea(4.0, 40.0)+"周长： "+a.getPerimeter(4.0, 40.0));
    System.out.printf("b的面积： %.1f周长：  %.1f",b.getPerimeter(3.5, 35.9),b.getArea(3.5, 35.9));    
  }

}



class Rectangle {//构造Rectangle类
  private double width = 1.0;
  private double height = 1.0;
  public Rectangle() {//无参构造方法
  }
  public double getArea(double width, double height) {//getArea方法
    return width * height;
  }
  public double getPerimeter(double width, double heigth) {//getPerimeter方法
    return (width + height) * 2;
  }

}
