package work3;

import java.util.Scanner;

public class TestRandom {

  /**
   产生随机数
   */
  public static void main(String[] args) {
   
   Scanner input=new Scanner(System.in);
   System.out.print("请输入： ");
   int s=input.nextInt();
   int temp=0;
   do{
   int a =(int)(Math.random()*1000);  
    if (a>=0&& a<100){
     System.out.println(a);
     temp++;}     
   }while (temp<s);//符合时继续
  }

}
