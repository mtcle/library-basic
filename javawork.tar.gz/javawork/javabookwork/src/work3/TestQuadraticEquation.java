package work3;

import java.util.Scanner;

public class TestQuadraticEquation {

  public static void main(String[] args) {
    System.out.println("a: ");
    @SuppressWarnings("resource")
    Scanner inputa = new Scanner(System.in);
    double x = inputa.nextDouble();
    System.out.println("b: ");
    @SuppressWarnings("resource")
    Scanner inputb = new Scanner(System.in);
    double y = inputb.nextDouble();
    System.out.println("c: ");
    @SuppressWarnings("resource")
    Scanner inputc = new Scanner(System.in);
    double z = inputc.nextDouble();
    QuadraticEquation test = new QuadraticEquation(x, y, z);
   if (test.getDiscriminant()==2) 
   System.out.printf("r1: %.2f r2:%.2f",test.getRoot1(),test.getRoot2());
   else if(test.getDiscriminant()==1){
     System.out.printf("r1=r2: %.2f",test.getRoot1());
   }
   else {
     System.out.println("无根！");
   }
  }
}



class QuadraticEquation {
  private double a;
  private double b;
  private double c;

  public QuadraticEquation(double a, double b, double c) {
    this.a = a;
    this.b = b;
    this.c = c;
  }

  public double getA() {
    return a;
  }

  public double getB() {
    return b;
  }

  public double getC() {
    return c;
  }

  public int getDiscriminant() {
    if (b * b - 4 * a * c > 0)
      return 2;
    else if (b * b - 4 * a * c == 0) {
      return 1;
    } else {
      return 0;
    }
  }

  public double getRoot1() {
    if (getDiscriminant() == 2) {
      return -b + Math.sqrt((b * b - 4 * a * c)) / 2 * a;
    } else if (getDiscriminant() == 0) {
//      System.out.print("无根！");
      return 0;
    } else {
//      System.out.print("同根：");
      return -b + Math.sqrt((b * b - 4 * a * c)) / 2 * a;
    }
  }

  public double getRoot2() {
    if (getDiscriminant() == 2) {
      return -b + Math.sqrt((b * b - 4 * a * c)) / 2 * a;
    } else if (getDiscriminant() == 0) {
//      System.out.print("无根！");
      return 0;
    } else {
//      System.out.print("同根：");
      return -b + Math.sqrt((b * b - 4 * a * c)) / 2 * a;
    }
  }

}
