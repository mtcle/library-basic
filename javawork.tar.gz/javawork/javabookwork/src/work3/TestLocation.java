package work3;

import java.util.Scanner;

public class TestLocation {

  public static void main(String[] args) {
   
    Location test=new Location();
   @SuppressWarnings("resource")
  Scanner input=new Scanner(System.in);
   
   System.out.print("Enter the number of rows and colomns of the array: ");
   int hang=input.nextInt();
   int lie=input.nextInt();
   double[][]ss=new double[hang][lie];
   System.out.println("Enter the array: ");
   for(int i=0;i<hang;i++){
     for(int j=0;j<lie;j++)
     {ss[i][j]=input.nextDouble();}
   }  
   test=Location.locateLargest(ss);
  System.out.println("The location of the largest element is: "+test.maxValue+" at: ( "+test.row+" , "+test.column+" )");
  }
}






 

class Location{
 public int row;
 public int column;
 public double maxValue;
 
 public static Location locateLargest(double[][] a){//定义寻找二维数组最大值的方法
   Location aaa=new Location();
   double tempmax=0;
   int i=0,j=0;
   for( i=0;i<a.length;i++){
     for( j=0;j<a[0].length;j++){
       tempmax= Math.max(a[i][j], tempmax);//调用了math类的max方法       
     }
   }
   
   
   
   for( i=0;i<a.length;i++){
     for( j=0;j<a[0].length;j++){
       if (tempmax==a[i][j]){
         aaa.row=i;
         aaa.column=j;
       };//查找下标最大值的下标。      
     }
   }
   aaa.maxValue=tempmax;
 return aaa;
 }
}