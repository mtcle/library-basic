package work3;

import java.util.Scanner;

public class TestLinear {

  public static void main(String[] args) {
   
   Scanner input=new Scanner(System.in);
   System.out.print("a: ");
   double a=input.nextDouble();
   System.out.print("b: ");

   double b=input.nextDouble();
   System.out.print("c: ");

   double c=input.nextDouble();
   System.out.print("d: ");

   double d=input.nextDouble();
   
   System.out.print("e: ");
   double e=input.nextDouble();
   System.out.print("f: ");
   double f=input.nextDouble();
   Linear test=new Linear(a,b,c,d,e,f);
   if (test.isSolvable()==false){
     System.out.println("The equation has no solution!");
   }
   else System.out.printf("x: %.2f y: %.2f",test.getX(),test.getY());
  }

}

class Linear{
  private double a,b,c,d,e,f;
  public Linear(double a,double b,double c,double d,double e,double f){
  this.a=a;this.b=b;
  this.c=c;this.d=d;
  this.e=e;this.f=f;
  }
  public double getA() {
    return a;
  }
  public double getB() {
    return b;
  }
  public double getC() {
    return c;
  }
  public double getD() {
    return d;
  }
  public double getE() {
    return e;
  }
  public double getF() {
    return f;
  }
  public boolean isSolvable(){
    if (a*d-b*c!=0)
      return true;
    else
      return false;
  }
  public double  getX(){
    double x=(e*d-b*f)/(a*d-b*c);
    return x;
  }
  public double getY(){
    double y=(a*f-e*c)/(a*d-b*c);
    return y;
  }
}