package work3;

public class TestStock {

  /**
   * @param args
   */
  public static void main(String[] args) {
    Stock a=new Stock("java","SunMicrosystems Inc",4.5,4.35);//根据自己定义的类new了一个新的对象，并且对其赋值。
    System.out.printf("当日该股票市值变化：%.4f",a.getChangePercent());
    System.out.print("%");
  }
}


class Stock{
  private String symbol;
  private String name;
  private double previousClosingPrice;
  private double currentPrice;
  
  public Stock(String symbol,String name,double previousClosingPrice,double currentPrice){//Stock类的构造方法
    this.symbol=symbol;
    this.name=name;
    this.previousClosingPrice=previousClosingPrice;
    this.currentPrice=currentPrice;
  }
  public double getChangePercent(){//获取市值变化百分百
      return (currentPrice-previousClosingPrice)/previousClosingPrice*100;
  }
}