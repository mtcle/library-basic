package work3;

public class TestRegularPolygon {

  /**
   * @param args
   */
  public static void main(String[] args) {
    RegularPolygon a1 = new RegularPolygon(6, 4);
    RegularPolygon a2 = new RegularPolygon(10, 4, 5.6, 7.8);
    System.out.printf("a1面积：%.1f周长是：%.2f", a1.getArea(), a1.getPerimeter());
    System.out.println();
    System.out.printf("a2面积：%.1f周长是：%.2f", a2.getArea(), a2.getPerimeter());
  }

}


class RegularPolygon {
  private int n;
  private double side;
  private double x = 0;
  private double y = 0;

  public RegularPolygon() {
    this.n = 3;
    this.side = 1.0;
    this.x = 0;
    this.y = 0;
  }

  public RegularPolygon(int n, double side) {// 带参数的构造方法
    this.n = n;
    this.side = side;
  }

  public RegularPolygon(int n, double side, double x, double y) {// 构造方法同名和类名相同，根据参数不同自动选择相应的构造方法
    this.n = n;
    this.side = side;
    this.x = x;
    this.y = y;
  }

  public int getN() {
    return n;
  }

  public void setN(int n) {
    this.n = n;
  }

  public double getSide() {
    return side;
  }

  public void setSide(double side) {
    this.side = side;
  }

  public double getX() {
    return x;
  }

  public void setX(double x) {
    this.x = x;
  }

  public double getY() {
    return y;
  }

  public void setY(double y) {
    this.y = y;
  }

  public double getPerimeter() {
    return n * side;
  }

  public double getArea() {
    return n * side * side / (4 * Math.tan(Math.PI / n));
  }
}
