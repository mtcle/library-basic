

 class Sequence{
 static  private int sum=1000;
  private String head="TP";
  @Override
  public String toString() {   
    return head+"-"+1000+"-"+sum++;
  }
}
