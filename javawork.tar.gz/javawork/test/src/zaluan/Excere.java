package zaluan;

import java.io.File;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Excere
{
  static String[] keywordString = { 
    "abstract", "assert", "boolean", 
    "break", "byte", "case", "catch", "char", "class", "const", 
    "continue", "default", "do", "double", "else", "enum", 
    "extends", "for", "final", "finally", "float", "goto", "if", 
    "implements", "import", "instanceof", "int", "interface", 
    "long", "native", "new", "package", "private", "protected", 
    "public", "return", "short", "static", "strictfp", "super", 
    "switch", "synchronized", "this", "throw", "throws", 
    "transient", "try", "void", "volatile", "while", 
    "true", "false", "null" };

  static Set<String> keywordSet = new HashSet(Arrays.asList(keywordString));

  static boolean stringToken = false;
  static String inputFileName;

  public static void main(String[] args) throws Exception
  {
    if (args.length != 2) {
      System.out.println(
        "Usage: java Exercise22_10 javaSourcefile htmlfile");
      System.exit(0);
    }

    Scanner input = new Scanner(new File(args[0]));

    PrintWriter output = new PrintWriter(new File(args[1]));

    JavaToHTML(input, output);
  }

  public static void JavaToHTML(Scanner input, PrintWriter output)
  {
    try
    {
      output.format("%s\r\n", new Object[] { "<html>" });
      output.format("%s\r\n", new Object[] { "<head>" });
      output.format("%s\r\n", new Object[] { 
        "<title>Intro to Java Programming, 6E - " + inputFileName + 
        "</title>" });
      output.format("%s\r\n", new Object[] { 
        "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">" });
      output.format("%s\r\n", new Object[] { "<style type = \"text/css\">" });
      output.format("%s\r\n", new Object[] { 
        "body {font-family: \"Courier New\", sans-serif; font-size: 100%; color: black}" });

      output.format("%s\r\n", new Object[] { 
        ".keyword {color: #000080; font-weight: bold}" });
      output.format("%s\r\n", new Object[] { ".comment {color: #008000}" });
      output.format("%s\r\n", new Object[] { ".literal {color: #0000ff}" });

      output.format("%s\r\n", new Object[] { "</style>" });

      output.format("%s\r\n", new Object[] { "</head>" });
      output.format("%s\r\n", new Object[] { "<body>" });
      output.format("%s\r\n", new Object[] { "<pre>" });

      String text = "";

      while (input.hasNext()) {
        String temp = input.nextLine();
        text = text + temp + "\r\n";
      }

      text = text.replaceAll(">", "&gt;");
      text = text.replaceAll("<", "&lt;");
      translateToHTML(text, input, output);

      output.format("%s\r\n", new Object[] { "</pre>" });
      output.format("%s\r\n", new Object[] { "</body>" });
      output.format("%s\r\n", new Object[] { "</html>" });
    }
    catch (Exception ex) {
      System.out.println(ex);
      try
      {
        input.close();
        output.close();
      }
      catch (Exception localException1)
      {
      }
    }
    finally
    {
      try
      {
        input.close();
        output.close();
      }
      catch (Exception localException2)
      {
      }
    }
  }

  static void translateToHTML(String text, Scanner input, PrintWriter output) throws Exception {
    text = text.replaceAll("// ", "LINECOMMENT");
    text = text.replaceAll("/\\*", "BLOCKCOMMENT");

    while ((text != null) && (text.length() > 0))
    {
      String[] parts = text.split("[%\\+\\-\\*/\r\n\t \\[\\].;(){},]", 2);

      String token = parts[0];

      if ((token.length() > 1) && (token.startsWith("LINECOMMENT"))) {
        output.format("%s", new Object[] { "<span class = \"comment\">" });
        parts = text.split("\r\n", 2);
        text = parts[1];
        output.format("%s", new Object[] { parts[0].replaceAll("LINECOMMENT", "// ") });
        output.format("%s", new Object[] { "</span>\r\n" });
      }
      else if ((token.length() > 1) && (token.startsWith("BLOCKCOMMENT"))) {
        output.format("%s", new Object[] { "<span class = \"comment\">" });
        parts = text.split("\\*/", 2);
        text = parts[1];

        output.format("%s", new Object[] { parts[0].replaceAll("BLOCKCOMMENT", "/*") + "*/" });
        output.format("%s", new Object[] { "</span>" });
      }
      else {
        if ((token.length() > 1) && (token.matches("'\\w'*"))) {
          output.format("%s", new Object[] { "<span class = \"literal\">" });
          output.format("%s", new Object[] { token });
          output.format("%s", new Object[] { "</span>" });
        }
        else if ((token.startsWith("\"")) && (token.endsWith("\"")) && 
          (token.length() > 1)) {
          output.format("%s", new Object[] { "<span class = \"literal\">" + token + 
            "</span>" });
        }
        else if ((token.startsWith("'")) && (token.endsWith("'")) && 
          (token.length() > 1)) {
          output.format("%s", new Object[] { "<span class = \"literal\">" + token + 
            "</span>" });
        }
        else if (token.equals("' '")) {
          output.format("%s", new Object[] { "<span class = \"literal\">" + token + 
            "</span>" });
        }
        else if ((token.startsWith("\"")) && (token.endsWith("\"")) && 
          (token.length() == 1)) {
          if (stringToken) {
            output.format("%s", new Object[] { token + "</span>" });
            stringToken = false;
          }
          else {
            output.format("%s", new Object[] { "<span class = \"literal\">" + token });
            stringToken = true;
          }
        }
        else if (token.startsWith("\"")) {
          output.format("%s", new Object[] { "<span class = \"literal\">" + token });
          stringToken = true;
        }
        else if ((token.endsWith("\"")) && (!token.endsWith("\\\""))) {
          output.format("%s", new Object[] { token });
          output.format("%s", new Object[] { "</span>" });
          stringToken = false;
        }
        else if (token.matches("\\d+")) {
          output.format("%s", new Object[] { "<span class = \"literal\">" + token + 
            "</span>" });
        }
        else if ((!stringToken) && (keywordSet.contains(token))) {
          output.format("%s", new Object[] { "<span class = \"keyword\">" + token + 
            "</span>" });
        }
        else {
          output.format("%s", new Object[] { token });
        }

        if (token.length() < text.length()) {
          if (text.charAt(token.length()) == '<')
            output.format("%s", new Object[] { "&lt;" });
          else if (text.charAt(token.length()) == '>')
            output.format("%s", new Object[] { "&gt;" });
          else {
            output.format("%s", new Object[] { Character.valueOf(text.charAt(token.length())) });
          }
        }
        if (parts.length == 2)
          text = parts[1];
      }
    }
  }
}