package zaluan;

import sourse.Employee;

public class TestPair {
  @SuppressWarnings("unchecked")
  public static void main(String[] args) {
    Pair<String> test = new Pair<String>("java", "hello");
    System.out.println(test.getFirst());
    System.out.println(test.getSecond());
    int[] aaa = {0, 1, 2, 8, 4, 2, 4};
    Integer[] abc = {0, 1, 2, 8, 4, 2, 4};
    String[] bbb = {"aaa", "bbb", "cccc"};
    System.out.println("max: " + maxmin(aaa).getFirst() + " min: " + maxmin(aaa).getSecond());
    @SuppressWarnings("unused")
    String bbbccc = new String();
    System.out.println(TestPair.<String>getMiddle("aa", "dd", "cc"));
    System.out.println(TestPair.<Integer>getMiddle(1, 2, 3));
    System.out.println(TestPair.<Long>getMiddle(121221l, 1122l, 2l));
    System.out.println(TestPair.getMiddle("aa", 122212, "hhhh"));// 没有指明参数类型默认是对象
    System.out.println(TestPair.<String>min(bbb));
    System.out.println(TestPair.<Integer>min(abc));
    Long[] x = {121221l, 1122l, 2l};
    System.out.println(TestPair.<Long>min(x));
    Employee[] a = new Employee[2];
    a[0] = new Employee("dd", "zz", 5);
    a[1] = new Employee("cc", "aa", 10);
    System.out.println(TestPair.<Employee>min(a));
  }

  @SafeVarargs
  public static <T> T getMiddle(T... a) {//静态方法必须跟个<T>规范
    return a[a.length / 2];
  }

  public static Pair<Integer> maxmin(int[] a) {
    int max = 0;
    int min = 0;
    for (int i = 0; i < a.length; i++) {
      if (a[i] > max) {
        max = a[i];
      }
    }
    min = a[0];
    for (int i = 0; i < a.length - 1; i++) {
      if (min > a[i + 1]) {
        min = a[i + 1];
      }
    }
    return new Pair<Integer>(max, min);
  }


  public static <T extends Comparable<T>> T min(T[] a) {
    if (a == null || a.length == 0) return null;
    T smallest = a[0];
    for (int i = 0; i < a.length; i++) {
      if ((smallest).compareTo(a[i]) > 0) smallest = a[i];
    }
    return smallest;
  }

}
