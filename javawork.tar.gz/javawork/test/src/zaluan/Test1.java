package zaluan;
/**
 * 接口的多重继承
 * */
interface CanFight {
  void fight();
}


interface CanSwim {
  void swim();
}


interface CanFly {
  void fly();
}


class Honesty {
  public Honesty() {
    System.out.println("class::ActionCharacter:honesty");
  }
}


class Hero extends Honesty implements CanFight, CanSwim, CanFly {
  public void fight() {
    System.out.println("fight");
  }

  public void swim() {
    System.out.println("Swin");
  }

  public void fly() {
    System.out.println("fly");
  }
}


public class Test1 {//主方法类
  static void t(CanFight x) {
    x.fight();
  }

  public static void main(String[] args) {
    Hero h = new Hero();
    t(h); // Treat it as a CanFight
  }
}
