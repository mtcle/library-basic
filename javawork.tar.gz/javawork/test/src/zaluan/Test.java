package zaluan;

public class Test {
//  public static final int MULTILINE=0;
  public static void main(String[] args) {
   
    String test="sdksdlllds/**jhjjkj*/" +
        "//ddf 'df;''ds;;//pppppp 9(ddd)d\n" +
        "\n" +
        "hhhghgg//yyhhg";
     String a= test.replaceAll("/**", "LINECOMMENT");
//     a=a.replaceAll("^\n", "----+-----");
//     System.out.println(a.matches("//"));
      System.out.println(a);

  }
}
