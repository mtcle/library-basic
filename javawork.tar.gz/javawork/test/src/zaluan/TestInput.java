package zaluan;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class TestInput {

  public static void main(String[] args) throws FileNotFoundException {
    Scanner input =new Scanner(new File("123.txt"));
    System.out.println(input.nextLine());
  }

}
