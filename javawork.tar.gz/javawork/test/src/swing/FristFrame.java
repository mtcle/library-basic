package swing;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import java.awt.*;

public class FristFrame {

  public static void main(String[] args) {
    SwingUtilities.invokeLater(new Runnable() {
      @Override
      public void run() {
        SimpleFrame frame = new SimpleFrame();
        JButton b = new JButton("123");
        JLabel c=new JLabel("你好");
        JTextField d=new JTextField("java");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setTitle("hello");
        frame.setLocation(300, 200);                                            
        frame.add(b);
        frame.add(c);
        
        
        c.setForeground(Color.RED);
        c.setFont(Font.getFont("宋体"));
//        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        
//        System.out.println(ge.getDefaultScreenDevice());
        // frame.pack();
        // frame.setSize(Toolkit.getDefaultToolkit().getScreenSize());
        frame.setResizable(true);
        System.out.println(Toolkit.getDefaultToolkit().getScreenSize());
        System.out.println(Toolkit.getDefaultToolkit().getScreenResolution());
         Image imageIcon = new ImageIcon("eclipse.gif").getImage();// 先把图片转换成icon形式的
         frame.setIconImage(imageIcon);
         frame.setExtendedState(Frame.MAXIMIZED_BOTH);
         frame.setSize(Toolkit.getDefaultToolkit().getScreenSize());
      }
    });



  }

}


@SuppressWarnings("serial")
class SimpleFrame extends JFrame {
  private static final int DEFAULT_WIDTH = 300;
  private static final int DEFAULT_HIGHT = 200;

  public SimpleFrame() {
    setSize(DEFAULT_WIDTH, DEFAULT_HIGHT);

  }

}
