//就是分别获得参数，主要是Math下的pow函数的运用，pow（a，b）=a^b
import java.util.Scanner;//引入util包

public class Test1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);//这是获取终端输入的方式和格式
		System.out.print("请输入年利率：");
		double yearRate = input.nextDouble();// 获取年利率
		double monthRate = yearRate / 1200;
		System.out.print("请输入年份");
		int yearCount = input.nextInt();
		System.out.print("输入贷款总额");
		double moneyCount = input.nextDouble();
		// 计算金额
		double monthPay = moneyCount * monthRate
				/ (1 - 1 / Math.pow((1 + monthRate), (yearCount * 12)));
		System.out.println("月还款：" + monthPay + "\n" + "总还款" + monthPay * 12
				* yearCount);
	}

}
