import java.util.Scanner;


public class Testmyself {

  /**
   * use the Math.random() to get a char
   */
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.print("\nEnter the sum of words of your article:\n");//"\n" is the char of change line.
    int n = input.nextInt();
    System.out.println("The artcl ：");
    for (int i = 1; i <= n; i++) {  
      if (i%10==0){
     System.out.println(changeToChar());}
      else {
        System.out.print(changeToChar());
      }
    }
  }

  public static char changeToChar() {
   char strChar=(char)(randomCode());
   return strChar; 
  }


  public static int randomCode() {//随机数产生
    int p;
    p = (int) (Math.random() * (int)('Z'-'A')+(int)('A'));
    return p;
   
  }
}
