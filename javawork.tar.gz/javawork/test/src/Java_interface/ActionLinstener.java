package Java_interface;

public interface ActionLinstener {//定义一个接口类
/**
 * void performed()==public abstract void performed()
 * 因为接口中所有的数据域都是public final static修饰的
 * 可以忽略*/
  void performed();//定义一个抽象方法，没有具体方法体，让继承者实现
}
