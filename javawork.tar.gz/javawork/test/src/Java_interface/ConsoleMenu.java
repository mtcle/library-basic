package Java_interface;

public class ConsoleMenu {

  private String label;
  private ActionLinstener listener;
/**
 * 带参数的构造函数
 * */
  public ConsoleMenu(String label, ActionLinstener linstener) {
    this.label = label;
    this.listener = linstener;
  }

  public String getLabel() {
    return label;
  }

  public void setListener(ActionLinstener listener) {
    this.listener = listener;
  }

  public void click() {
    this.listener.performed();
  }
/**
 * 每个类都得重写系统的toString方法
 * 这是良好的编程习惯
 * */
  @Override
  public String toString() {
    return super.toString();
  }
}
