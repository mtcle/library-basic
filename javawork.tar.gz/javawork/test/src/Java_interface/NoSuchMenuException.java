package Java_interface;

public class NoSuchMenuException extends RuntimeException {
  private static final long serialVersionUID = -2244751268583084101L;

  public NoSuchMenuException() {
    super("no such menu item!");//调用父类的带参构造方法
  }
}
