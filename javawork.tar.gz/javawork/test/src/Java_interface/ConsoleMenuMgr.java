package Java_interface;

import java.util.ArrayList;
import java.util.List;

public class ConsoleMenuMgr {

  private static final List<ConsoleMenu> MENUS = new ArrayList<ConsoleMenu>(6);

  private ConsoleMenuMgr() {}
  public static void add(ConsoleMenu menu) {
    MENUS.add(menu);
  }

  public static void remove(ConsoleMenu menu) {
    MENUS.remove(menu);
  }

  public static void remove(int idx) {
    MENUS.remove(idx - 1);
  }

  public static void invoke(int idx) {
    if (idx <= 0 || idx > MENUS.size()) throw new NoSuchMenuException();
    MENUS.get(idx - 1).click();
  }

  public static String showMenu() {
    StringBuilder sb = new StringBuilder();
    sb.append("--------------------------------------------\n");
    for (int i = 0; i < MENUS.size(); i++) {
      sb.append((i + 1));
      sb.append(". | ");
      sb.append(MENUS.get(i).getLabel());
      sb.append("\n");
    }
    sb.append("--------------------------------------------\n");
    return sb.toString();
  }}
  