package Java_interface;
/**
 *实现对ActionLinstener接口的实现
 *接口里面的抽象方法继承者实现
 *对performed（）方法实现了
 **/
public class DefaultActionLinstener implements ActionLinstener {

  @Override
  public void performed() {
    System.out.println("hello default");
  }

}
