import javax.swing.*;
public class TestGui {
  /**
   * @param args
   */
  public static void main(String[] args) {
    // TODO Auto-generated method stub
    int sum=0;
    int a=JOptionPane.YES_OPTION;
    while (a==JOptionPane.YES_OPTION){
        String bb=JOptionPane.showInputDialog("输入一个数值:");
        int cc=Integer.parseInt(bb);
        sum=sum+cc;
        a=JOptionPane.showConfirmDialog(null,"还需要继续输入么？");
        
        
    }
    JOptionPane.showMessageDialog(null,"sum： "+sum);
  }

}
