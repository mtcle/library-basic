import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import javax.swing.Timer;



public class TestInnerClass {

  public static void main(String[] args) { 
    
  }

}



class TalkingClock{
  private int interval;
  private boolean beep;
  public TalkingClock(int interval,boolean beep){
    this.interval=interval;
    this.beep=beep;    
  }
  
  public void start(){
    ActionListener listener=new TimerPrinter();
    Timer t=new Timer(interval,listener);
    t.start();
  }
  public class TimerPrinter implements ActionListener{
    @Override
    public void actionPerformed(ActionEvent e){
      Date now=new Date();
      System.out.print("the time si "+now);
      if (beep) Toolkit.getDefaultToolkit().beep();
    }
  }
  
  
  
  
  
 
}