public class Test_Print_tranganl {

  /**
   * @param args
   */
  public static void main(String[] args) {
    int i = 6;
    int j = 1;
    int q = 0;
    for (j = 1; j <= 6; j++) {
      for (i = 6; i > j; i--) {
        System.out.print(" ");
      }
      for (q = j; q >= 1; q--) {
        System.out.print(q);
        if (q == 1) System.out.println();
      }
    }
  }
}
