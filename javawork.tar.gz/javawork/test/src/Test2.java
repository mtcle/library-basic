// 这个是测试currentTimeMillis()的使用，这个函数是当前时间-格林威治时间
public class Test2 {
  public static void main(String[] args) {
    double timeCount1 = System.currentTimeMillis();

    double i = 1, n = 10000000, sum = 0;
    for (i = 1; i <= n; i++)
      System.out.print("");
    double timeCount2 = System.currentTimeMillis();
    System.out.println(timeCount2 - timeCount1);

  }
}
