package other_test_12_2_to7;

public class Javatest99运用自定义方法模块 {    //类，一个类里面可以有多个方法，只能有一个main方法
  static int i;

  /**
   运用方法调用来做的
   */
  public static void main(String[] args)  //主方法，主方法是static则只能调用定义的静态的方法
  {          
    for (i = 1; i < 10; i++)
    {
        hangJiSuan(i);
    }

  }

  public static void hangJiSuan(int i) //自己定义的方法，可以在主方法内部定义，也可以在主方法外定义。 
  {   
    for (int j = 1; j <= i; j++) 
    {
      int sum = i * j;
      System.out.printf("%d*%d=%d \t", j, i, sum);
    }
    System.out.printf("\n");
  }

}