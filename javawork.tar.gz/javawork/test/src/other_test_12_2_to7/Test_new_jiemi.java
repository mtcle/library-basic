package other_test_12_2_to7;

public class Test_new_jiemi {
  public static void main(String args[]) {
    String str = "hhkskk";
    StringBuffer mingwenBuffer = new StringBuffer();//聲明字符容器
    StringBuffer miwenBuffer = new StringBuffer();
    char[] strArray = str.toCharArray();// 将用户字符串转换成数组
    char mi[] =
        {'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k',
            'l', 'z', 'x', 'c', 'v', 'b', 'n', 'm'};
    char ming[] =
        {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'l',
            's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

    int i = 0, j = 0;
    for (j = 0; j < strArray.length; j++) {
      for (i = 0; i < 26; i++) {
        if (strArray[j] == ming[i]) // 对比数组的值
        {
          mingwenBuffer.append(mi[i]);// 将找到的正确结果追加给mi[]数组
        }
      }
    }
    System.out.println(mingwenBuffer.toString());// 将结果赋值成字符串


  }

}
// 本程序要运用模块拆分 建立方法



