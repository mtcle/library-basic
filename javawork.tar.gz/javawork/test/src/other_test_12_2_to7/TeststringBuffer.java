package other_test_12_2_to7;

public class TeststringBuffer {

  /**
   * @param args
   */
  public static void main(String[] args) {
  System.out.println("aaa");
  }
  public static String toString(int[] ary) {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < ary.length; i++) {
      if (i % 2 != 0) {
        sb.append(" " + (char) ary[i] + " ");
      } else {
        sb.append(ary[i]);
      }
    }
    return sb.toString();
   
  }
//  System.out.print(ary[3]);
}
