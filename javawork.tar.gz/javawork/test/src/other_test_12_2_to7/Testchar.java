package other_test_12_2_to7;

import java.util.Scanner;

public class Testchar {

  public static void main(String[] args) {
   Scanner input=new Scanner(System.in);
   System.out.println("Enter a number between 0-128:");
   int a=input.nextInt();
   System.out.println("the number "+a+" ASCII is:"+(char)a);//测试
    
    
  }

}
