package other_test_12_2_to7;

public class Testif {

  /** test if
   */
  public static void main(String[] args) {
    char[] aaaa={'1','+','9','x','3','+','4','='};
    int i;
//    for (i=0;i<aaaa.length;i++){
//    if (aaa[i]=="+")
//      temp=(Integer.valueOf(ssChar[j-2]+ssChar[j-1]))*(Integer.valueOf(ssChar[j+1]+ssChar[j+2]));
//      System.out.println(Integer.valueOf(aaa[i-1])+Integer.valueOf(aaa[i+1]));//
    
//    if (aaaa[i]=='x'){
      System.out.print(((aaaa[3-1]-48))*(aaaa[3+1]-48)) ;
//      break;
    }
     
     
    
    
  }


