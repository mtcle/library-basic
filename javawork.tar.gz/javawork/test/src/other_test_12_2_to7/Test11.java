package other_test_12_2_to7;

//import java.math.BigDecimal;

public class Test11 {

 public static void main(String[] args) {
//    double ft=95.0331777;
//    int scale = 4;//设置位数
//    int roundingMode=4;//表示四舍五入，可以选择其他舍值方式，例如去尾，等等.
//    BigDecimal bd = new BigDecimal((double)ft);
//    bd = bd.setScale(scale,roundingMode);
//    ft = bd.floatValue();
//System.out.println(ft);
  }
}
