package other_test_12_2_to7;
/*打印任意年月分的日历
 * by mtcle
 ******************
 */
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class PrintCalender {
  public static void main(String[] args) // 主方法
  {

    
    Scanner input = new Scanner(System.in);
//    System.out.print("Enter the year:");
    String input2=JOptionPane.showInputDialog(null,"请输入一个年份：","年份" ,JOptionPane.QUESTION_MESSAGE);
    
//    int year = input.nextInt();
    String temp=input2;
    int year = Integer.valueOf(temp);
//    System.out.print("Enter the month:");
//    int month = input.nextInt();
    String input3=JOptionPane.showInputDialog(null,"输入月份:","月份",JOptionPane.QUESTION_MESSAGE);
   String temp2=input3;
   int month=Integer.valueOf(temp2);
    printMonth(year, month);// 调用定义好的printMonth（）方法
  }

  public static void printMonth(int year, int month) // 打印月份
  {
//    printMonthTitle(year, month);// 调用打印抬头的方法
//    printMonthBody(year, month);// 调用打印内容的方法
//    JOptionPane.showMessageDialog(null, printMonthTitle(year,month));
    JOptionPane.showMessageDialog(null, printMonthTitle(year,month).append(printMonthBody(year,month)));
  }

  public static StringBuffer printMonthTitle(int year, int month) // 打印日历抬头
  {
//    System.out.println("            \t " +year + " 年 " + month + " 月的月历");
//    System.out.println("--------------------------------------------------");
//    System.out.println("Sun\tMon\tTue\tWed\tThu\tFri\tSat");
    // 方法
    StringBuffer str=new StringBuffer();
    str.append("               " +year + " 年 " + month + " 月的月历\n"+
        "-----------------------------------------------\n"+"Sun  Mon  Tue  Wed  Thu  Fri  Sat\n");
//    JOptionPane.showMessageDialog(null, str);
    return str;
  }

  public static StringBuffer printMonthBody(int year, int month) // 打印日历内容
  {
    StringBuffer ss=new StringBuffer();
    int startday = getStartDay(year, month);
    int monthDaysTotal = getNumberOfDaysInMonth(year, month);
    int i = 0;
    for (i = 0; i <startday; i++) {
//      System.out.print("\t");// 打印日历开始的空白
      ss.append("         ");
    }
    for (i = 1; i <= monthDaysTotal; i++)// 打印数字
    {
      if (i<10) 
//      System.out.print(i+"\t");// 不太懂格式化打印
      ss.append(i+"       ");
      else
        ss.append(i+"     ");
      if ((i + startday) % 7 == 0) {
//        System.out.println("");
        ss.append("\n");
      }// 处理换行问题
    }
//    System.out.println();
    
    return ss;
  }

  public static int getStartDay(int year, int month)// 获取日历该月第一天的开头日期
  {
    final int YUAN1800_1_1 = 3;// 定义一个初始的月份的1800.1.1为星期三的常量
    int monthDaysTotal = getTotalDays(year, month);
    return (monthDaysTotal + YUAN1800_1_1) % 7;// 和其实位置相加后除7求余？？？
  }

  public static int getTotalDays(int year, int month) {
    int total = 0, i;
    for (i = 1800; i < year; i++) {
      if (isLeapYear(i) == true)// 判断润年否
      {
        total = total + 366;
      } else {
        total = total + 365;
      }// 计算到了该年之前的天数
    }
    for (i = 1; i < month; i++) {
      total = total + getNumberOfDaysInMonth(year, i);
    }
    return total;
  }

  public static int getNumberOfDaysInMonth(int year, int month)// 获取该月天数
  {
    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10
        || month == 12) {
      return 31;
    } else if (month == 2) {
      if (isLeapYear(year) == true)
        return 29;
      else
        return 28;
    } else
      return 30;
  }

  public static boolean isLeapYear(int year)// 判断是否是润年
  {
    return year % 400 == 0 || (year % 100 != 0 && year % 4 == 0);
  }

  public static String getMonthName(int month) {
    String monthName = " ";
    switch (month) {
      case 1:
        monthName = "yi1";
        break;
      case 2:
        monthName = "yi2";
        break;
      case 3:
        monthName = "yi3";
        break;
      case 4:
        monthName = "yi4";
        break;
      case 5:
        monthName = "yi5";
        break;
      case 6:
        monthName = "yi6";
        break;
      case 7:
        monthName = "yi7";
        break;
      case 8:
        monthName = "yi8";
        break;
      case 9:
        monthName = "yi9";
        break;
      case 10:
        monthName = "yi10";
        break;
      case 11:
        monthName = "yi11";
        break;
      case 12:
        monthName = "yi12";
        break;
    }
    return monthName;
  }
}
