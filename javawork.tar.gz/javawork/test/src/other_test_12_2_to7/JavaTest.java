package other_test_12_2_to7;

public class JavaTest {

  public static void main(String[] args) {
    System.out.print(max(1.0, 2.0));
    // 方法的重载，根据参数自动调用匹配的方法

  }

  public static double max(double a, double b) {
    if (a > b)
      return a;
    else
      return b;

  }

  public static int max(int a, int b) {
    if (a > b)
      return a;
    else
      return b;

  }
}
