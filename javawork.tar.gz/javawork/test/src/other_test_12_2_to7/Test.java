package other_test_12_2_to7;

public class Test {


  public static void main(String[] args) {
    // TODO Auto-generated method stub
    int[]a1={1,2,3};
    add(a1);
    System.out.println(a1[0]);
  }
 
  
  public static void add(int[] a1){
      a1=new int[]{987,8976,78};
      
      }    
  }
