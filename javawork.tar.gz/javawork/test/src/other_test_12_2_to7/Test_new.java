//這是老師給的方法，思路是將兩個字符串的ascii對比。
package other_test_12_2_to7;
import java.util.*;
public class Test_new {
  private static final String LOWER_CASE_KEY = "qwertyuiopasdfghjklzxcvbnm";
  private static final String UPPER_CASE_KEY = "QWERTYUIOPASDFGHJKLZXCVBNM";

  public static void main(String[] args) {
    Scanner input =new Scanner(System.in);
    System.out.print("Enter the word:");
    String str=input.next();
    System.out.println(encodingString(str));
  }

  private static String encodingString(String str) {
    char[] charOfStr = str.toCharArray();
    StringBuilder result = new StringBuilder();
    for (int i = 0; i < charOfStr.length; i++) {
      result.append(encodeingOneCharacter(charOfStr[i]));
    }
    return result.toString();
  }

  private static char encodeingOneCharacter(char ch) {
    if (isLetter(ch)) {
      if (isUpperCaseLetter(ch)) {
        ch = UPPER_CASE_KEY.charAt(ch - 'A');
      } else {
        ch = LOWER_CASE_KEY.charAt(ch - 'a');
      }
    }
    return ch;
  }

  private static boolean isLetter(char ch) {
    return isLowerCaseLetter(ch) || isUpperCaseLetter(ch);
  }

  private static boolean isLowerCaseLetter(char ch) {
    return ch >= 97 && ch <= 122;
  }

  private static boolean isUpperCaseLetter(char ch) {
    return ch >= 65 && ch <= 90;
  }
}
