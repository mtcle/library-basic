package sourse;
public abstract class Person {// 抽象类，必须有个抽象方法才能叫做抽象类
  private String name;

  public abstract String getDescription();// 抽象方法，自己不用定义方法内容，这是让别人调用时构造的，没有大括号及内容的。

  public String getName() {
    return name;
  }

  public Person(String name) {// 构造方法
    this.name = name;
  }

  @Override
  public boolean equals(Object obj) {
    // TODO Auto-generated method stub
    return super.equals(obj);
  }
}
