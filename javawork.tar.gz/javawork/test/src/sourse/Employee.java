package sourse;

/**
 * 下面是定义一个类，也就是相当于系统的 那种Array类，方便我们自己直接调用引用
 */
@SuppressWarnings("rawtypes")
public class Employee extends Person implements Comparable,Cloneable {
  // private String name;//自己类内的定义成私有的 安全，别的类不能调用//由于继承自Person类
  private String dateinto;// 像这些基本不能改变的都应该定义成私有的
  public String getDateinto() {
    return dateinto;
  }

  public void setDateinto(String dateinto) {
    this.dateinto = dateinto;
  }

  private double salary;

  public Employee(String name, String dateinto, double salary) {// 这个是构造函数，无返回值，名字和类名相同
    super(name);// 区分内部参数和外部参数的，也可以不同名字 this指的是自己的 不是引入的参数
    this.dateinto = dateinto;
    this.salary = salary;
  }


  public String getDateIne() {// 获取入职日期
    return dateinto;
  }

  public double getSalary() {
    return salary;
  }

  public double addSalary() {// 涨工资
    return salary = salary + 1000;
  }
  @Override
  public String toString() {// 这是从写了系统的toString（）每一个类都要重写一下toStrng方法，因为系统么人的是把地址toString（）了，类里面是要重写下打印字符串的
    return this.getName() + this.getDateIne() + this.getSalary();
  }


  @Override
  public String getDescription() {
    this.getName();
    return this.getName();
  }

  /*
   * 系统的equals是判断两者的内存地址的，明显不符合咱们的要求，所以要改写成判断字符串的
   */
  @Override
  public boolean equals(Object obj) {// 重写了系统Object类下的equals方法
    if (obj instanceof Employee) {// a instanceof B 是判断对象a是否是类B的对象类型。
      Employee a = (Employee) obj;// 强制转换成Employee的数据类型
      return (this.getName().equals(a.getName()) && this.getDateIne().equals(a.getDateIne()) && this.salary == a
          .getSalary());
      // 判断非基本数据类型的不能用‘==’只能用equals()方法。

    } else
      return false;
  }

  @Override
  public int compareTo(Object o) {
    // if(o instanceof Employee){
    Employee xx = (Employee) o;
    // if (this.getSalary()==xx.getSalary()){
    // return 0;}
    // else if (this.getSalary()<xx.getSalary())
    // return 1;
    // else
    // return -1;
    // }
    // return -1;
    // }
    return Double.compare(this.getSalary(), xx.getSalary());// 直接调用系统类的方法
  }

  @Override
  protected Object clone() throws CloneNotSupportedException {
    return super.clone();
  }



}