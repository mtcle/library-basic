package sourse;

public class Manager extends Employee {
  private double bonus;

  public Manager(String name, String dateinto, double salary) {// 子类的构造方法
    super(name, dateinto, salary);// 引入父类的参数
  }

  public void setBonus(double x) {
    this.bonus = x;
  }
  
  public double getBonus() {
    return bonus;
  }

  @Override
  // 重载父类的方法
  public double getSalary() {// 这个是自己的方法 由于和超类的同名，但是重构了
    return super.getSalary() + bonus;// 区分自己的还是超类的getSalary（）方法
  }
  
  
  @Override
  public boolean equals(Object obj) {// 重写了系统Object类下的equals方法
    if (obj instanceof Manager) {// a instanceof B 是判断对象a是否是类B的对象类型。
      Manager a = (Manager) obj;// 强制转换成Manager的数据类型
      return (this.getName().equals(a.getName()) && this.getDateIne().equals(a.getDateIne()) && this.getSalary() == a
          .getSalary()&& this.bonus==a.bonus);
      // 判断非基本数据类型的不能用‘==’只能用equals()方法。

    } else
      return false;
  }
 @Override
 public String toString(){//这是从写了系统的toString（）
   return "重写的toString："+this.getName()+this.getDateIne()+this.getBonus();
 }

}
