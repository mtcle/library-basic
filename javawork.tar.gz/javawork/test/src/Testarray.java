import java.util.Arrays;


public class Testarray {


  public static void main(String[] args) {
    int[][] a = {{1, 2},{2,3}};
   // int[] b = {1, 2, 5};
    System.out.println(a.length);// 结果也不对

  }


}
